<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-07 21:21:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:21:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:24:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:24:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:24:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:24:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:25:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:25:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:41:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-07 21:41:04 --> 404 Page Not Found: Assets/images
