<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-21 08:35:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 08:35:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 08:39:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 08:39:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 11:28:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 11:28:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 15:38:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 15:38:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 15:39:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-21 15:39:48 --> 404 Page Not Found: Assets/images
