<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-03 10:33:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 10:33:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:02:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:02:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:02:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:02:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:03:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:03:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:04:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-03 16:04:51 --> 404 Page Not Found: Assets/images
