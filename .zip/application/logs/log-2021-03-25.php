<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-25 08:29:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 08:29:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 09:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 09:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 11:12:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 11:12:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 11:18:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 11:18:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 14:41:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 14:41:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 14:42:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 14:42:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 17:36:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-25 17:36:24 --> 404 Page Not Found: Assets/images
