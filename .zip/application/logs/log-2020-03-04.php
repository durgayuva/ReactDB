<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-04 08:21:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-04 08:21:15 --> 404 Page Not Found: Assets/images
