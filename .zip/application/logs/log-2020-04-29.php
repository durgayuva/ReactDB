<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-29 10:42:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:42:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:42:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:42:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:44:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:44:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 11:54:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 11:54:50 --> 404 Page Not Found: Assets/images
