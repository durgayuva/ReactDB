<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-04 11:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:57:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:57:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:58:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:58:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:58:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:58:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:59:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 11:59:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:20:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:20:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:20:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:20:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:21:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 12:21:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 14:03:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-04 14:03:05 --> 404 Page Not Found: Assets/images
