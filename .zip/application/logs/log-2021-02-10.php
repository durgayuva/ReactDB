<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 08:19:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-10 08:19:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-10 08:19:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-10 08:19:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-10 08:34:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-10 08:34:03 --> 404 Page Not Found: Assets/images
