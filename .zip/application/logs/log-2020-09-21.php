<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-21 09:13:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-21 09:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-21 14:21:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-21 14:21:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-21 14:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-21 14:22:28 --> 404 Page Not Found: Assets/images
