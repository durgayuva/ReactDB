export const ActionTypes = {
    USER_LOGIN: "USER_LOGIN",
};