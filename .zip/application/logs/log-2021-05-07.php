<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-07 12:07:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-07 12:07:37 --> 404 Page Not Found: Assets/images
