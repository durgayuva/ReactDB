<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-19 11:29:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-19 11:29:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-19 11:29:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-19 11:29:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-19 21:16:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-19 21:16:55 --> 404 Page Not Found: Assets/images
