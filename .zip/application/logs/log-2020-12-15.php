<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 08:17:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 08:17:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 08:59:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 08:59:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 08:59:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 08:59:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 09:00:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 09:00:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 09:39:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 09:39:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 16:08:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-15 16:08:34 --> 404 Page Not Found: Assets/images
