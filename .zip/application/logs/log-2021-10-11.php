<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 17:48:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-11 17:48:48 --> 404 Page Not Found: Assets/images
