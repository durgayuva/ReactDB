<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-06 10:16:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-06 10:16:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-06 10:16:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-06 10:16:58 --> 404 Page Not Found: Assets/images
