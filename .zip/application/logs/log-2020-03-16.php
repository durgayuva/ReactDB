<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 07:49:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-16 07:49:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-16 08:09:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-16 08:09:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-16 10:56:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-16 10:56:41 --> 404 Page Not Found: Assets/images
