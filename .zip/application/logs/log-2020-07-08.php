<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 08:41:52 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-07-08 08:42:03 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-07-08 08:42:18 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-07-08 12:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:24:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:24:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:25:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:25:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:26:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:26:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:29:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:29:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:29:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-08 12:29:42 --> 404 Page Not Found: Assets/images
