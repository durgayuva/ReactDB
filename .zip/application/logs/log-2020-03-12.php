<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-12 11:05:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:05:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:21:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:21:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:30:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:30:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:44:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-12 11:44:02 --> 404 Page Not Found: Assets/images
