
<form action="" class="form-horizontal" role="form" method="post" enctype="multipart/form-data" id="remark_form" name="remark_form">

<input type="hidden" id="id" name="id" value="<?php echo $id;?>" />
<input type="hidden" id="page" name="page" value="<?php echo $page;?>" />

<div class="row">
	<div class="col-sm-2"></div>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Remark</strong></label>
			<div class="col-sm-4">
				<textarea class="form-control elastic" name="it_remark" id="it_remark" required></textarea>
			</div>
	</div>
</div>

<div class="text-center">
	<button type="submit" class="btn btn-rounded btn-sm bg-danger-800" id="remark" name="remark">Submit &nbsp;<i class="icon-circle-right2"></i></button>
</div>

<div id="display"></div>

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url'); ?>" />

</form>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 

<script>

$(document).ready(function() {
	
	$('.elastic').autosize();
	
});

</script>	