<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-10 11:28:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-10 11:28:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-10 11:32:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-10 11:32:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-10 11:37:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-10 11:37:14 --> 404 Page Not Found: Assets/images
