<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-29 09:29:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-29 09:29:08 --> 404 Page Not Found: Assets/images
