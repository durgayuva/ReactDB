<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-30 09:46:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-30 09:46:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-30 09:47:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-30 09:47:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-30 14:34:47 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-03-30 14:34:53 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-03-30 14:35:03 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-03-30 14:35:15 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-03-30 14:35:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-30 14:35:47 --> 404 Page Not Found: Assets/images
