<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-30 13:49:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:49:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:50:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:50:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:51:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:51:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:52:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 13:52:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 14:35:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 14:35:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:13:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:13:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:15:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:15:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:19:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:19:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:22:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-30 15:22:47 --> 404 Page Not Found: Assets/images
