<div class="sidebar-content">
	<div class="sidebar-category sidebar-category-visible">
		<div class="category-content no-padding">
			<ul class="navigation navigation-main navigation-accordion">
				<li class="navigation-header"><span style="color:#ffb3ff;"><b>Main</b></span> <i class="icon-menu" title="Main pages"></i></li>
				<li <? if(request()->segment(2)=='home') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/home'?>"><i class="icon-home4"></i><span>DashBoard</span></a></li>
				<li <? if(request()->segment(2)=='new_request') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/new_request' ?>"><i class="icon-new"></i><span>Request Creation</span></a></li>
				<li <? if(request()->segment(2)=='myreq' || request()->segment(2)=='viewcreation' || request()->segment(2)=='editcreation') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/myreq' ?>"><i class="icon-pen2"></i><span>My Creation</span></a></li>
				<?php 
				if((in_array(session()->get('empname'), config('app.master_access'))) || (in_array(session()->get('empname'), config('app.itheadname'))) || (in_array(session()->get('empname'), config('app.ithead1name'))) || (in_array(session()->get('empname'), config('app.feasi'))) || (in_array(session()->get('empuname'), config('app.hod_list')))) {
					?>
					<li>
						<a href="#"><i class="icon-stack2"></i><span>Approval</span></a>
						<ul>
							<?php 
							if((in_array(session()->get('empuname'), config('app.hod_list'))) || (in_array(session()->get('empname'), config('app.master_access')))) {
								?>
								<li <? if(request()->segment(2)=='hod' || request()->segment(2)=='hodapprove') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/hod' ?>"><i class="icon-folder-check"></i><span>HOD Approval</span></a></li>
								<?php 
							}
							if((in_array(session()->get('empname'), config('app.feasi'))) || (in_array(session()->get('empname'), config('app.master_access')))) {
								?>			
								<li <?php if(request()->segment(2)=='feasi' || request()->segment(2)=='feasiview') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/feasi' ?>"><i class="icon-bookmark"></i><span>Feasibility Study</span></a></li>
								<?php 
							}
							if((in_array(session()->get('empname'), config('app.itheadname'))) || (in_array(session()->get('empname'), config('app.ithead1name'))) || (in_array(session()->get('empname'), config('app.master_access'))) ) {
								?>	
								<li <?php if(request()->segment(2)=='ithead' || request()->segment(2)=='itapprove') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/ithead' ?>"><i class="icon-shield-check"></i><span>IT Head Approval</span></a></li>
								<?php 
							}
							?>
						</ul>
					</li>
					<?php 
				}  
				if((session()->get('empuname') != session()->get('hod') && session()->get('empdeptid') == 14) || (in_array(session()->get('empname'), config('app.master_access')))) {  
					?>	
					<li <?php if(request()->segment(2)=='tentdate') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/tentdate' ?>"><i class="icon-calendar3"></i><span>Project Details</span></a></li>
					<?php 
				}
				//if(session()->get('empdeptid') != 14 || (in_array(session()->get('empname'), config('app.master_access'))) ) {
					?> 
					<li <? if(request()->segment(2)=='UAT' || request()->segment(2)=='projdate') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/UAT' ?>"><i class="icon-user-check"></i><span>UAT Screen</span></a></li>
					<?php 
				//}
				//if((in_array(session()->get('empname'), config('app.itheadname'))) || (in_array(session()->get('empname'), config('app.ithead1name'))) || (in_array(session()->get('empname'), config('app.feasi'))) || (session()->get('empuname') == session()->get('hod')) || (in_array(session()->get('empname'), config('app.master_access')))) {
				//}
				?>
				<li <? if(request()->segment(2)=='report' || request()->segment(2) =='reportview') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/report' ?>"><i class="icon-indent-decrease2"></i><span>Report</span></a></li>
				
				<li <? if(request()->segment(2)=='portal_access_request') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/portal_access_request' ?>"><i class="icon-new"></i><span>Portal Access Request Creation</span></a></li>
				
				<li <? if(request()->segment(2)=='my_access_request_list') echo 'class="active"'; ?>><a href="<?php echo config('app.site_url').'/request/my_access_request_list' ?>"><i class="icon-pen2"></i><span>Portal Access Request List - My Creation</span></a></li>
				
				<li>
					<a href="#"><i class="icon-stack2"></i><span>Approval</span></a>
					<ul>
						
						<li <? if(request()->segment(2)=='get_approval_list') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/get_approval_list' ?>"><i class="icon-folder-check"></i><span>RO / HOD Approval</span></a></li>
						<?php 
						
						if((in_array(session()->get('empuname'), config('app.it_approval')))) {
							?>			
							<li <?php if(request()->segment(2)=='get_IT_approval_list') echo 'class="active"';?>><a href="<?php echo config('app.site_url').'/request/get_IT_approval_list' ?>"><i class="icon-bookmark"></i><span>Portal Team Approval</span></a></li>
							<?php 
						}
						
						
						?>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>