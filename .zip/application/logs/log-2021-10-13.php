<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-13 12:13:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-13 12:13:59 --> 404 Page Not Found: Assets/images
