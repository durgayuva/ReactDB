<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-12 08:02:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-12 08:02:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-12 08:03:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-12 08:03:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-12 08:04:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-12 08:04:40 --> 404 Page Not Found: Assets/images
