<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-09 08:07:29 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-06-09 11:23:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-09 11:23:22 --> 404 Page Not Found: Assets/images
