<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-18 14:28:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-18 14:28:18 --> 404 Page Not Found: Assets/images
