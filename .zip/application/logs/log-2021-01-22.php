<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-22 12:18:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 12:18:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 12:27:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 12:27:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 13:29:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 13:29:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 13:41:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-22 13:41:48 --> 404 Page Not Found: Assets/images
