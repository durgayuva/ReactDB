<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-07 08:21:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 08:21:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 08:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 08:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 09:03:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 09:03:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 09:03:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 09:03:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 16:15:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-07 16:15:08 --> 404 Page Not Found: Assets/images
