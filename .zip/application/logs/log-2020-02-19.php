<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-19 11:53:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-19 11:53:31 --> 404 Page Not Found: Assets/images
