<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 08:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:33:17 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:33:17 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:39:46 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-04 08:40:06 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-04 08:40:17 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-04 08:40:21 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-04 08:40:34 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:40:34 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:59:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 08:59:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:06:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:06:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:26:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:26:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:36:20 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:36:20 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:55:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 09:55:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:04:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:04:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:08:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:08:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:09:57 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 11:09:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:28:46 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:28:46 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:30:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:30:02 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:33:15 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:33:15 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:33:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:33:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:37:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:37:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:47:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:47:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 13:48:13 --> 404 Page Not Found: 848-SGA%20-%20Online%20portal%20templateppt/index
ERROR - 2019-12-04 14:00:35 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:00:35 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:05:56 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-12-04 14:06:18 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2019-12-04 14:08:55 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:08:56 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:10:17 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:10:17 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:15:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:15:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:17:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:17:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:17:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:30:46 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:32:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:32:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:33:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:33:01 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:33:06 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:34:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:34:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:35:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:36:36 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:36:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:36:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:41:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:41:54 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:42:47 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:44:32 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 14:44:32 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 15:10:19 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 15:10:19 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 16:06:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 16:06:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 17:15:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-04 17:15:53 --> 404 Page Not Found: Assets/images
