<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-06 10:34:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
AND `status` = "Submitted" 
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM `query_master`
WHERE `project_deptid` IN()
AND `status` = "Submitted" 
ORDER BY `id` DESC
ERROR - 2021-09-06 10:35:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-06 10:35:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-06 10:35:14 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-06 10:35:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-06 10:35:36 --> 404 Page Not Found: Assets/images
