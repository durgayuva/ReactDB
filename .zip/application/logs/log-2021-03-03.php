<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-03 09:09:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 09:09:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 11:10:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 11:10:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 11:10:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 11:10:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:06:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:06:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:09:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:09:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:10:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 12:10:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 13:15:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-03 13:15:43 --> 404 Page Not Found: Assets/images
