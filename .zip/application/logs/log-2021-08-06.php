<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-06 08:41:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-06 08:41:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-06 11:00:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-06 11:00:00 --> 404 Page Not Found: Assets/images
