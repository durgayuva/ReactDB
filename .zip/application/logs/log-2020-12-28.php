<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-28 08:14:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-28 08:14:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-28 17:10:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-28 17:10:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-28 17:10:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-28 17:10:43 --> 404 Page Not Found: Assets/images
