<?php //$sel = $this->db->query("SELECT * FROM system_desc_master where id=""); ?>
<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<div class="table-responsive">
<table class="table table-bordered table-xxs bordered table-striped dataTable no-footer" id="dataTables">
<thead>
<tr class="bg-slate-300">
	<th>Sl.No.</th>
	<th>Project Ref No</th>
	<th>Reqirement Type</th>
	<th>Project Title</th>
	<th>Project Department Name</th>
   <th>Priority</th>
	<th>Requested By</th>
	<th>Requested Department Name</th>
	<th>Status</th>
	<th>Action</th>
</tr>
	
</thead>
     
<tbody>
<?php  if(count($list) > 0) { 
	$j=1; 
	foreach($list as $records) {    // print_r($records); 
		$title = $generalModel->getDetails('system_desc','system_desc_master','id='.$records->system_desc_id.'');  
		$emp = $generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.$records->requested_by.'" '); 
		$projdept = $generalModel->getprojdept($records->system_desc_id);  
		$dept = $generalModel->getRaiseddept($records->requested_by);  
		$sts_name = $generalModel->Status_Color($records->status);
		$sts_app = $generalModel->status_aaproval($records->id);    
	?>      
	
<tr>
	<td><?php echo $j; ?></td>
	<td><?php echo $records->project_ref_no;?></td>
	<td><?php echo $records->system;?></td>
	<td><?php echo $title ;?></td>
	<td><?php echo $projdept[0]->dept_name;?></td>
	<?php if($records->project_priority !='') { ?>
	<td><?php echo $records->project_priority;?></td>
	<?php } else { ?>
	<td><?php echo '-';?></td>
	<?php } ?>
	<td><?php echo $emp;?></td>
	<td><?php echo $dept ;?></td>        
	<td><span class="label <?php echo $sts_name[0]->color_code;?>"><?if(($records->status!='Completed') && ($records->status !='Rejected') && ($records->status !='Hold'))  { echo $sts_name[0]->status_history.'<br/>('.$sts_app.')' ; } else { echo $sts_name[0]->status_history; } ?></span></td>
	
	<?php  if($page == 1) { ?>
	<td nowrap>
		<?php if($records->status =='Rerouted to User') { ?>
		<a href="<?php echo config('app.site_url').'/request/editcreation/'.$records->id;?>" class="btn btn-rounded btn-xs bg-danger-600" target="_blank"><i class="icon-pencil7"></i></a>&nbsp;&nbsp;
		<?php } ?>
		<a href="<?php echo config('app.site_url').'/request/viewcreation/'.$records->id;?>" class="btn btn-rounded btn-xs bg-brown-600" target="_blank"><i class="icon-book-play"></i></a>
	</td>
	
	<?php } else if($page ==2) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/hodapprove/'.$records->id;?>" class="btn btn-rounded btn-xs bg-purple-600" target="_blank"><i class="icon-checkmark-circle2"></i></a>&nbsp;&nbsp;
	</td>
	
	<?php } else if($page == 3) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/reportview/'.$records->id;?>" class="btn btn-rounded btn-xs bg-success-800" target="_blank"><i class="icon-book"></i></a>&nbsp;&nbsp;
	</td>
	
	<?php } else if($page == 4) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/feasiview/'.$records->id;?>" class="btn btn-rounded btn-xs bg-warning-800" target="_blank"><i class="icon-checkmark-circle2"></i></a>&nbsp;&nbsp;
	</td>
	
	<?php } else if($page ==5) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/itapprove/'.$records->id;?>" class="btn btn-rounded btn-xs bg-danger-800" target="_blank"><i class="icon-checkmark-circle2"></i></a>&nbsp;&nbsp;
	</td>
	
	<?php } else if($page == 6) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/projdate/'.$records->id;?>" class="btn btn-rounded btn-xs bg-pink-800" target="_blank"><i class="icon-checkmark-circle2"></i></a>&nbsp;&nbsp;
	</td>
	
	<?php } else if($page == 7) { ?>
	<td>
		<a href="<?php echo config('app.site_url').'/request/projdate/'.$records->id;?>" class="btn btn-rounded btn-xs bg-pink-800" target="_blank"><i class="icon-checkmark-circle2"></i></a>&nbsp;&nbsp;
	</td>
	
<?php } ?>
		
</tr>
 
<?php  $j++; }} else { ?>              
	
<tr>
	<td colspan="12" style="color:red;"> No Records Found </td>
</tr> 
<? } ?>
		
</tbody>
</table>
</div>
<?php /**PATH C:\xampp\htdocs\portal_request\resources\views/api/load_my_request.blade.php ENDPATH**/ ?>