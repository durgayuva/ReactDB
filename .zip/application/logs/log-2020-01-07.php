<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-07 10:03:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 10:03:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 10:32:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 10:32:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 10:55:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 10:55:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:43:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:43:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:44:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:44:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:49:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:49:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:50:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Portal '' at line 1 - Invalid query:  SELECT * FROM system_desc_master WHERE system_desc='Exchage Rate Mapping Thro' Portal ' 
ERROR - 2020-01-07 16:51:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Portal '' at line 1 - Invalid query:  SELECT * FROM system_desc_master WHERE system_desc='Exchage Rate Mapping Thro' Portal ' 
ERROR - 2020-01-07 16:59:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-07 16:59:54 --> 404 Page Not Found: Assets/images
