<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-10 16:31:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-10 16:31:50 --> 404 Page Not Found: Assets/images
