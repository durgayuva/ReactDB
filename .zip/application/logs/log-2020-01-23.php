<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-23 08:22:23 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-01-23 08:22:30 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-01-23 08:23:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 08:23:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 08:36:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 08:36:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 08:38:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 08:38:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:28:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:28:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:29:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:29:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:30:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 11:30:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:04:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:04:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:18:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:18:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:20:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-23 14:20:23 --> 404 Page Not Found: Assets/images
