<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-18 14:59:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 14:59:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:02:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:02:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:03:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:03:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:08:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:08:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:39:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-18 15:39:11 --> 404 Page Not Found: Assets/images
