<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-17 15:29:43 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('', NULL)
ERROR - 2020-10-17 15:29:44 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('', NULL)
ERROR - 2020-10-17 15:29:52 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('', NULL)
ERROR - 2020-10-17 15:29:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:29:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:32:06 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('', NULL)
ERROR - 2020-10-17 15:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:32:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:33:04 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('Weekly and monthly projects status updation  ', NULL)
ERROR - 2020-10-17 15:33:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 15:35:50 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('Weekly and monthly projects status updation  ', NULL)
ERROR - 2020-10-17 15:53:10 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('Weekly and monthly projects status updation  ', NULL)
ERROR - 2020-10-17 16:00:54 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('Weekly and monthly projects status updation  ', NULL)
ERROR - 2020-10-17 16:13:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 16:13:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 16:16:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-17 16:16:53 --> 404 Page Not Found: Assets/images
