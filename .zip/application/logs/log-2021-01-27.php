<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 10:26:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 10:26:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 10:31:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 10:31:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 11:02:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 11:02:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 11:02:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-27 11:02:59 --> 404 Page Not Found: Assets/images
