<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 13:58:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 13:58:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 15:59:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 15:59:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:08:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:08:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:21:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:21:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:21:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-03 16:21:55 --> 404 Page Not Found: Assets/images
