<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-08 08:14:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-08 08:14:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-08 11:02:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-08 11:02:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-08 11:04:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-08 11:04:35 --> 404 Page Not Found: Assets/images
