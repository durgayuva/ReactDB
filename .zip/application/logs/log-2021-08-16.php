<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-16 11:37:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-16 11:37:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-16 16:39:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-16 16:39:07 --> 404 Page Not Found: Assets/images
