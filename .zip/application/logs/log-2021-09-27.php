<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-27 09:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-27 09:22:22 --> 404 Page Not Found: Assets/images
