<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-31 15:20:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:20:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:21:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:21:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:25:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:25:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:27:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:27:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:27:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:27:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:33:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-31 15:33:25 --> 404 Page Not Found: Assets/images
