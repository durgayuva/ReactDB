<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-22 12:26:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 12:26:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:44:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:44:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:46:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:46:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:55:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-22 13:55:43 --> 404 Page Not Found: Assets/images
