<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 16:54:49 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-03 16:54:49 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-03 16:55:26 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-03 16:55:26 --> 404 Page Not Found: Assets/images
