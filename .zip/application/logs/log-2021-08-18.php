<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-18 10:49:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-18 10:49:55 --> 404 Page Not Found: Assets/images
