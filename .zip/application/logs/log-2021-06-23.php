<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-23 08:59:21 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-23 08:59:21 --> 404 Page Not Found: Assets/images
