<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-19 08:39:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-19 08:39:07 --> 404 Page Not Found: Assets/images
