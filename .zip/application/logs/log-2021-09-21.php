<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-21 09:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 09:54:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 14:00:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 14:00:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 14:00:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 14:00:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:23:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:23:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:24:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:24:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:28:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-21 16:28:51 --> 404 Page Not Found: Assets/images
