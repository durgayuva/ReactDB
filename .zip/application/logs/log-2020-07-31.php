<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-31 08:02:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:02:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:05:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:05:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:13:25 --> Query error: Table 'portal_request.vendors' doesn't exist - Invalid query: SELECT *
FROM `vendors`
WHERE `created_by` IN ('msatishk','dmeenaks','gthulasi','gdavid01','kmadhava','vveerapa','masusila','ppreman','vjagades','msendhil','rharish','Nsaravan','krameshk','ndsenth','gmohana','amariaan','vshiva','anandkrish','knikhil','gbharath','pvasanth','EO0160','EO0233','EO0239','EO0260','sparames','drsowmiya','DT885','DT897','DT902','gkumares','trajkumar','vrajesh','dmanikand','IT1122','IT1124','IT1123','IT1151','IT1170','IT1232','DT928','DT930','DT931','ssuresh','nvaratha','skamesh','rsadeesh','pshanmuga','pkamaraj','DT1036','DT1084','DT1120','IT1353','IT1384','IT1386','IT1452','pgvignes','rprithiv','pjayacha','NE139','NE142','NE157','NE161','sshuntho','skabil','ksivaji','yalexsam','jlalith','asenthil','csathish','rvasant','ckingdav','rsraga','rvenkat','mdhaksh','sseenu','rrajesh','mthanigai','dadhavan','mbalaji','bsingkaraj','kjayap','sramu','duablab','vchris','bkarthik','kvenu','rsarank','swconsult1','swconsult2','swconsult3','swconsult4','swconsult5','eashok','durablab','swconsult6','mponram','telavar','rakila','smohamed','njayakumar','mveera','kssuresh','asathish','mvisuram')
AND `status` = "S" 
ORDER BY `vendor_id` DESC
ERROR - 2020-07-31 08:15:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:15:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:18:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-31 08:18:29 --> 404 Page Not Found: Assets/images
