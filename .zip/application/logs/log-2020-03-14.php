<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-14 11:35:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-14 11:35:33 --> 404 Page Not Found: Assets/images
