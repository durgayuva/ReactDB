<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-08 08:52:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 08:52:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 08:53:39 --> Severity: Warning --> unlink(c:/wamp64/tmp\ci_session050e1dc1940e73156dc7b764bec30b301282193e): Permission denied D:\htdocs\ci_system\libraries\Session\drivers\Session_files_driver.php 371
ERROR - 2020-08-08 08:53:39 --> Severity: Warning --> unlink(c:/wamp64/tmp\ci_sessiona8b31bc73010dfa2d2984f3f25ce2a610bed97c6): Permission denied D:\htdocs\ci_system\libraries\Session\drivers\Session_files_driver.php 371
ERROR - 2020-08-08 08:53:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 08:53:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 09:27:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 09:27:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 11:59:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 11:59:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 12:26:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-08 12:26:34 --> 404 Page Not Found: Assets/images
