<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>IT APLICATION REQUEST SYSTEM</title>

<!-- Global stylesheets starts -->

<!-- Global stylesheets starts -->
		
		<!-- To get the arrow mark below the log out button -->
<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
<!-- Global stylesheets ends -->

<!-- Core JS files starts -->
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>
<!-- Core JS files ends -->
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/highcharts.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/data.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/exporting.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/export-data.js"></script>
</head>
@inject('generalModel','App\Models\GeneralModel')
@inject('userModel','App\Models\UserModel')
<? use Illuminate\Support\Facades\DB; ?>
<body>

<?php  //$layout_header;?> 
@include('layout.header')
<!-- Page container starts -->
<div class="page-container"> 

	<!-- Page content -->
<div class="page-content"> 

	<!-- Main sidebar -->
<div class="sidebar sidebar-main"> @include('layout.sidebar') </div>
    <!-- /main sidebar --> 

  <!-- Main content -->
<div class="content-wrapper"> 
		
	<!-- Page header -->
<div class="breadcrumb-line">
<ul class="breadcrumb">
	<li><a href=""<i class="icon-home2 position-left"></i> Home</a></li> <!-- To Give Space in the class="icon-home2" <i> ..</i> -->
	</ul>
</div>

<div class="content">

<form class="form-horizontal" role="form" method="post" enctype="multipart/form-data" id="chartboard" name="chartboard">

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" />	

<div class="panel border-danger-300">
<div class="panel-heading bg-danger-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>Dashboard</strong></h6>
</div>

<div class="panel-body">

<?php if((session()->get('empuname') != session()->get('hod')) && (session()->get('empdeptid') != 14)) { 
	
	$empdetails = $generalModel->getUserdet();  
	if(count($empdetails) > 0) { 
?>

<div class="row">
<div class="col-sm-6" id="container1" style="width:auto; height:450px; margin:0 auto">

<?php $sts = $generalModel->getstatus();
		$colorArr = array('#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#cc80ff','#ff5c33');  
		$i=0;
	
	foreach($sts as $row)  { 
		$status[] = "'".$row->status_desc."'";
		
		$emp = $generalModel->getempchart(session()->get('empuname'),$row->status_desc); 
		$dataArr[] = "{ 
			y:".$emp." ,    		// display the count of the status (i.e Y-Axis content)
			color :'".$colorArr[$i]."'   // display color to the respective status all data's stored in a array
		}";
		$i++; 
	}
	$stss = implode(',',$status);  
?>
</div>
</div>

<br/>

<?php }  else { ?> 

<p style="color:red;"><b>Content will be updated soon.....</b></p>

<?php } } if((session()->get('empuname') == session()->get('hod')) && (session()->get('empdeptid') != 14)) { 

	$query = DB::connection('mysql')->select("select * from query_master where emp_deptid =".session()->get('empdeptid')." ");
	$result = $query;
	
	if(count($result) > 0) {

?>
	
<div class="row">
<div class="col-sm-6" id="container2" style="width:auto; height:450px; margin:0 auto">>

<?php $sts = $generalModel->getstatus();
		$colorArr = array('#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#cc80ff','#ff5c33');  
		$i=0;
	
	foreach($sts as $row)  { 
		$stat[] = "'".$row->status_desc."'";
		
		$row = $generalModel->gethodchart(session()->get('empdeptid'),$row->status_desc	); 
		$data[] = "{ 
			y:".$row." ,    		
			color :'".$colorArr[$i]."'   
		}";
		$i++; 
	}
	$status = implode(',',$stat);  
?>

</div>
</div>

<?php } else { ?>

<p style="color:red;"><b>Content will be updated soon.....</b></p>

<?php } }  if(session()->get('empdeptid') == 14)	{  

	$query = DB::connection('mysql')->select("select * from query_master ");
	$res = $query;
	
	if(count($res) > 0) {
?>

<div class="row" id="container3" style="width:auto; height:450px; margin:0 auto">	

<?php $dept = $userModel->getAlldepartment();  
	
foreach($dept as $depart)  {
	$deptname[] = "'".$depart->dept_name."'";
	
	$sts = $generalModel->getStatuscount($depart->dept_id, 'status IN ("Submitted","Rerouted to User", "HODApproved", "Feasibility Checked", "ITHead Approved", "Inprocess", "Awaiting for UAT", "UAT Accepted") ');
	$Oplan[] = $sts;
		
	$stat = $generalModel->getStatuscount($depart->dept_id, 'status IN ("Rejected", "Completed")');
	$Cplan[] = $stat;
	
	$tot = $generalModel->getOverallcount($depart->dept_id);
	$totalval[] = $tot;
}

$department = implode(',',$deptname);	
$open = implode(',',$Oplan);    
$close = implode(',',$Cplan);	
$total = implode(',',$totalval);

?>

</div>
<hr>

<div class="row">

<div class="form-group">
<label class="control-label col-sm-2"><strong>Department</strong></label>
	<div class="col-sm-3">
	<select class="" name="dept" id="dept">
	<option value="0" selected>All</option> 
		 <?php $depart =$userModel->getAlldepartment();
				foreach($depart as $depid){ ?>
			<option value="<?php echo $depid->dept_id;?>" > <?php echo $depid->dept_name;?></option>
		<?php } ?>
	</select>
	</div>
</div>
<br/>

<div class="row" id="container4" style="width:auto; height:450px; margin:0 auto">	

<?php $list = $generalModel->getstatus(); 
		$colorArr = array('#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#cc80ff','#D4AF37','#ff5c33');  
		$i=0;
	foreach($list as $rows)  { 	
		$stss [] = "'".$rows->status_desc."'";
		
		$value = $generalModel->gethodchart(0,$rows->status_desc); 
		$depdata[] = "{ 
			y:".$value." ,    		
			color :'".$colorArr[$i]."'   
		}";
		$i++;
	}
	$status = implode(',',$stss);  
	$data = implode(',',$depdata);  
?>
</div>

<div id="container5"></div>

</div>

<?php } else { ?>

<p style="color:red;"><b>Content will be updated soon.....</b></p>

<?php } } ?>

</form>

</div>
										
</div>

<?php  //$layout_footer;?>
@include('layout.footer')
</div>
</div>
 
</div>
</div>
</div>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/autosize.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
		<!-- Line will generate (dash line) will generate while loading -->
		
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/sweet_alert.min.js"></script>  
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/uniform.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/custom.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/main.js"></script>

<script>

<?php if((session()->get('empuname') != session()->get('hod')) && (session()->get('empdeptid') != 14)) {
	if(count($empdetails) > 0) { 
 ?>
$('#container1').highcharts({
   chart: {
		type:'column'
	},
	title:{
        text: 'IT Ticketing User Status'
    },
	yAxis: [{
		min: 0,
		labels: { 
			style: {
				color: 'red',
			}
		},
		lineWidth: 1,
		title: {
			text: 'No. of count',
			style: {
				color: 'green',fontSize:'14px'
			}
		}
	}],
	xAxis: {
        categories: [<? echo $stss;?>]
    },
	plotOptions: {
	series: {
		dataLabels:{
		enabled:true,
		color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
		style: {
			textShadow: '0 0 3px black'
		},
		formatter:function(){
			if(this.y > 0)
				return this.y;
		}
		}
	}
	},
	series: [{ 
			data: [<?php echo implode(',',$dataArr);?>],    
	}]
}); 

<?php } } if((session()->get('empuname') == session()->get('hod')) && (session()->get('empdeptid') != 14)) { 
	if(count($result) > 0) {  
?>
$('#container2').highcharts({
   chart: {
		type:'column'
	},
	title:{
        text: 'IT Ticketing Departmentwise Status'
    },
	yAxis: [{
		min: 0,
		labels: { 
			style: {
				color: 'red',
			}
		},
		lineWidth: 1,
		title: {
			text: 'No. of count',
			style: {
				color: 'green',fontSize:'14px'
			}
		}
	}],
	xAxis: {
        categories: [<? echo $status;?>]
    },
	plotOptions: {
	series: {
		dataLabels:{
		enabled:true,
		color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
		style: {
			textShadow: '0 0 3px black'
		},
		formatter:function(){
			if(this.y > 0)
				return this.y;
		}
		}
	}
	},
	series: [{ 
			data: [<?php echo implode(',',$data);?>],    
	}]
}); 

<?php } } if(session()->get('empdeptid') == 14) { 
	if(count($res) > 0) {
?>

$('#container3').highcharts({
   chart: {
		type:'column'
	},
	title:{
        text: 'IT Ticketing OverAll Status'
    },
	yAxis: [{
		min: 0,
		labels: { 
			style: {
				color: 'red',
			}
		},
		lineWidth: 1,
		title: {
			text: 'No. of count',
			style: {
				color: 'green',fontSize:'14px'
			}
		}
	}],
	xAxis: {
        categories: [<? echo $department;?>]
    },
	plotOptions: {
	series: {
		dataLabels:{
		enabled:true,
		color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
		style: {
			textShadow: '0 0 3px black'
		},
		formatter:function(){
			if(this.y > 0)
				return this.y;
		}
		}
	}
	},
	series: [
		{
		name: 'Open',
		data: [<? echo $open ;?>],
		color: '#D4AF37',
		stack: 'open'
		},
		{
		name: 'Close',
		data: [<? echo $close;?>],
		color: '#F08080',
		stack: 'open'
		},
		{
		name: 'OverAll Count',
		data: [<? echo $total;?>],
		color: '#008080',
		stack: 'open'
		}
	]
}); 

$('#container4').highcharts({
   chart: {
		type:'column'
	},
	title:{
        text: 'IT Ticketing - Departmentwise Status'
    },
	yAxis: [{
		min: 0,
		labels: { 
			style: {
				color: 'red',
			}
		},
		lineWidth: 1,
		title: {
			text: 'No. of count',
			style: {
				color: 'green',fontSize:'14px'
			}
		}
	}],
	xAxis: {
        categories: [<? echo $status;?>]
    },
	plotOptions: {
	series: {
		dataLabels:{
		enabled:true,
		color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
		style: {
			textShadow: '0 0 3px black'
		},
		formatter:function(){
			if(this.y > 0)
				return this.y;
		}
		}
	}
	},
	series: [{ 
		data: [<?php echo $data ;?>],    
	}]
}); 

<?php }  } ?>

</script>

</body>
</html>