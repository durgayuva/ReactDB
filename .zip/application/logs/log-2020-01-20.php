<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-20 13:36:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-20 13:36:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-20 13:37:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-20 13:37:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-20 13:37:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-20 13:37:52 --> 404 Page Not Found: Assets/images
