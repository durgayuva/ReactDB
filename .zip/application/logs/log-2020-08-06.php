<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-06 07:56:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-06 07:56:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-06 08:46:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-06 08:46:56 --> 404 Page Not Found: Assets/images
