<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-17 08:45:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 08:45:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:02:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:02:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:03:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:03:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:20:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 09:20:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:35:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:35:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:39:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:39:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:40:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:40:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:41:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:41:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:41:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-17 13:41:55 --> 404 Page Not Found: Assets/images
