<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

function __construct() {
parent::__construct();
	$this->load->library('comportal');
	$this->load->model('user_model');
}

public function index(){      // To load login page intially
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	
	if($this->session->userdata("empid") != "") {
		redirect(ADMIN_URL.'request/home');
	}
	$this->load->view('login', $data);
}	
		
public function loginvalidate() { 
	$this->load->library('form_validation');
	
	if($this->input->post('uname')) { 
		if ($this->user_model->Check_user_exists($this->input->post('uname'))) {
			$this->form_validation->set_rules('uname', 'Username', 'required');  
			$this->form_validation->set_rules('pwd', 'Password', 'required');
	
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();  
			} 
			
			else {	
				$row = $this->user_model->get_userdata($this->input->post('uname', TRUE));
				sleep(2);
				if(count($row)> 0 ) {
														
				// ******************  LDAP CONNECTIVITY STARTS HERE  ********************** 
														
					$ldaprdn = $this->input->post('uname', TRUE); // ldap rdn or dn  // comdev03 
												
					$ldappass = $this->input->post('pwd', TRUE); // associated password	->system password(window password)		
												
					$ldaprdn = $ldaprdn.'@comstarauto.com';   // comdev03@comstarauto.com
												
					$ldapconn = ldap_connect("portalad") or die("Could not connect to LDAP server.");
															
				// *******************  LDAP CONNECTIVITY ENDS HERE  ************************
														
					/*if ($ldapconn) {   #START
						$ldapbind = @ldap_bind($ldapconn, $ldaprdn, $ldappass);
						if ($ldapbind) { #END*/
						
							// ***************    TO SET USERDATA FOR LOGIN (SESSION)Initialization   *************************

							$userData['empid'] = $row['cs_emp_id'];  		// To set empid
							$userData['empuname'] = $row['cs_emp_username']; 
							$userData['empname'] = $row['cs_emp_name'];  
							$userData['empemail'] = $row['cs_emp_email'];
							$userData['empdeptid'] = $row['cs_emp_dept_id']; 
							$userData['deptname'] = $row['cs_emp_dept']; 
							$userData['hod'] = $row['cs_emp_hod'];  
							$userData['emp_hod'] = $row['cs_emp_hod'];						
							$userData['emp_ro'] = $row['cs_emp_ro'];						
							$this->session->set_userdata($userData);
							echo 1; 
							exit;
						/*} else {    #START
							echo 2;
						}				
					} else {  
						echo 3;   
					}     #END* */
				}	
				echo 4;
			}
		} else {
			echo 4;
			exit;
		}		
	}
}
	
public function logout() {
	$this->comportal->logout(); 
}  

public function test()
{
	$sel = $this->db->query("SELECT * FROM query_master WHERE 1 AND requested_by = 'mmuthu' ORDER BY id desc");
	$res = $sel->row_array();
	print_r($res);
	
	echo "<br><br>";
	
	$sel_x = $this->db->query("SELECT * FROM `portal_access_request` WHERE `status` = 'S' ORDER BY access_id desc");
	$res_x = $sel_x->row_array();
	print_r($res_x);
}

}

?>