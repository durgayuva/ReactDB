<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:25 --> Severity: Notice --> Undefined variable: disp E:\wamp\www\working\app_request\application\views\dashboard.php 303
ERROR - 2019-11-12 14:43:25 --> Severity: Notice --> Undefined variable: dispdata E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:25 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 321
ERROR - 2019-11-12 14:43:25 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 350
ERROR - 2019-11-12 14:43:25 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:43:25 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 368
ERROR - 2019-11-12 14:59:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:01 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:02 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:02 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:23 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:23 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:23 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:23 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 14:59:24 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 14:59:24 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:00:09 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:00:09 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:00:09 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:00:09 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:00:09 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:00:09 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:07 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 153
ERROR - 2019-11-12 15:02:07 --> Severity: Error --> Call to a member function getOverallcount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 153
ERROR - 2019-11-12 15:02:07 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 153
ERROR - 2019-11-12 15:02:07 --> Severity: Error --> Call to a member function getOverallcount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 153
ERROR - 2019-11-12 15:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:31 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:31 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:31 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:32 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:32 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:32 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:32 --> Severity: Error --> Call to a member function getStatuscount() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 147
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:51 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:51 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:52 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:52 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:53 --> Severity: Notice --> Undefined variable: depdisp E:\wamp\www\working\app_request\application\views\dashboard.php 400
ERROR - 2019-11-12 15:02:53 --> Severity: Notice --> Undefined variable: depdata E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:02:53 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 418
ERROR - 2019-11-12 15:07:25 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:07:25 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:00 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:00 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:00 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:00 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:01 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:02 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:03 --> Severity: Notice --> Undefined property: CI_Loader::$request_model E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:03 --> Severity: Error --> Call to a member function getstatus() on a non-object E:\wamp\www\working\app_request\application\views\dashboard.php 185
ERROR - 2019-11-12 15:09:20 --> Severity: Error --> Call to undefined method Request_Model::getdeptwise() E:\wamp\www\working\app_request\application\views\dashboard.php 191
ERROR - 2019-11-12 15:09:21 --> Severity: Error --> Call to undefined method Request_Model::getdeptwise() E:\wamp\www\working\app_request\application\views\dashboard.php 191
ERROR - 2019-11-12 15:09:21 --> Severity: Error --> Call to undefined method Request_Model::getdeptwise() E:\wamp\www\working\app_request\application\views\dashboard.php 191
ERROR - 2019-11-12 15:09:21 --> Severity: Error --> Call to undefined method Request_Model::getdeptwise() E:\wamp\www\working\app_request\application\views\dashboard.php 191
ERROR - 2019-11-12 15:09:22 --> Severity: Error --> Call to undefined method Request_Model::getdeptwise() E:\wamp\www\working\app_request\application\views\dashboard.php 191
ERROR - 2019-11-12 15:12:34 --> Severity: Notice --> Undefined variable: depid E:\wamp\www\working\app_request\application\views\api\load_Deptchart.php 9
ERROR - 2019-11-12 15:12:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND status ='Submitted' GROUP BY status' at line 1 - Invalid query:  SELECT status,count(id) as count FROM query_master where emp_deptid = AND status ='Submitted' GROUP BY status 
ERROR - 2019-11-12 15:12:43 --> Severity: Notice --> Undefined variable: depid E:\wamp\www\working\app_request\application\views\api\load_Deptchart.php 9
ERROR - 2019-11-12 15:12:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND status ='Submitted' GROUP BY status' at line 1 - Invalid query:  SELECT status,count(id) as count FROM query_master where emp_deptid = AND status ='Submitted' GROUP BY status 
ERROR - 2019-11-12 15:14:56 --> Severity: Notice --> Undefined variable: status E:\wamp\www\working\app_request\application\views\dashboard.php 316
ERROR - 2019-11-12 15:14:56 --> Severity: Notice --> Undefined variable: data E:\wamp\www\working\app_request\application\views\dashboard.php 334
ERROR - 2019-11-12 15:14:56 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 334
ERROR - 2019-11-12 15:15:22 --> Severity: Notice --> Undefined variable: status E:\wamp\www\working\app_request\application\views\dashboard.php 316
ERROR - 2019-11-12 15:15:22 --> Severity: Notice --> Undefined variable: data E:\wamp\www\working\app_request\application\views\dashboard.php 334
ERROR - 2019-11-12 15:15:22 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 334
ERROR - 2019-11-12 15:19:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'VENKATESH' at line 1 - Invalid query: SELECT * FROM query_master WHERE requested_by =A VENKATESH 
ERROR - 2019-11-12 15:20:02 --> Severity: Notice --> Undefined variable: stss E:\wamp\www\working\app_request\application\views\dashboard.php 271
ERROR - 2019-11-12 15:20:02 --> Severity: Notice --> Undefined variable: dataArr E:\wamp\www\working\app_request\application\views\dashboard.php 289
ERROR - 2019-11-12 15:20:02 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 289
ERROR - 2019-11-12 15:20:02 --> Severity: Notice --> Undefined variable: stss E:\wamp\www\working\app_request\application\views\dashboard.php 271
ERROR - 2019-11-12 15:20:02 --> Severity: Notice --> Undefined variable: dataArr E:\wamp\www\working\app_request\application\views\dashboard.php 289
ERROR - 2019-11-12 15:20:02 --> Severity: Warning --> implode(): Invalid arguments passed E:\wamp\www\working\app_request\application\views\dashboard.php 289
