<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-05 09:07:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 09:07:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:12:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:12:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:15:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:15:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:18:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-05 16:18:15 --> 404 Page Not Found: Assets/images
