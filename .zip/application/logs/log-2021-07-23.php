<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-23 08:31:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:31:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:32:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:32:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:33:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:33:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:34:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:34:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:39:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-23 08:39:32 --> 404 Page Not Found: Assets/images
