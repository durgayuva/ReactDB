<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-21 09:30:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 09:30:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 09:31:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 09:31:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 10:20:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 10:20:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 10:20:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 10:20:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 15:04:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 15:04:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 15:04:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 15:04:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 16:45:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-21 16:45:41 --> 404 Page Not Found: Assets/images
