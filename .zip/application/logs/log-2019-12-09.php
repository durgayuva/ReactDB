<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-09 07:46:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 07:46:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:26 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:26 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:56 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 08:05:56 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 11:28:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 11:28:39 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 11:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 11:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 14:41:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 14:41:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 14:42:27 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-09 14:42:27 --> 404 Page Not Found: Assets/images
