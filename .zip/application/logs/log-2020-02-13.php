<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-13 16:02:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-13 16:02:48 --> 404 Page Not Found: Assets/images
