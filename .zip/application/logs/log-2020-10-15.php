<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-15 09:37:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-15 09:37:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-15 14:14:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-15 14:14:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-15 14:16:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-15 14:16:39 --> 404 Page Not Found: Assets/images
