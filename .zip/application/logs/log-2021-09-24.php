<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-24 12:03:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 12:03:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 12:14:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 12:14:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 12:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 12:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:15:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:15:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:17:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:17:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:22:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:22:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:59:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 14:59:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 17:46:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 17:46:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 17:47:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-24 17:47:59 --> 404 Page Not Found: Assets/images
