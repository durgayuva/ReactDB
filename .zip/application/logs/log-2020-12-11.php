<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-11 12:36:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 12:36:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 13:43:15 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-12-11 13:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:43:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:43:34 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-12-11 13:44:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:46:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:46:32 --> Severity: Notice --> Trying to get property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:46:32 --> Severity: Notice --> Trying to get property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:46:32 --> Severity: Notice --> Trying to get property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> Attempt to modify property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> Attempt to modify property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> Attempt to modify property of non-object D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\htdocs\portal_request\application\models\Request_Model.php 111
ERROR - 2020-12-11 13:47:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
AND `status` = "Submitted" 
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM `query_master`
WHERE `project_deptid` IN()
AND `status` = "Submitted" 
ORDER BY `id` DESC
ERROR - 2020-12-11 13:47:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\htdocs\ci_system\core\Exceptions.php:272) D:\htdocs\ci_system\core\Common.php 573
ERROR - 2020-12-11 13:47:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-12-11 13:48:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 13:48:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 15:22:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 15:22:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 15:24:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-11 15:24:10 --> 404 Page Not Found: Assets/images
