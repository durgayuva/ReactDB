import axios from 'axios';

export const axiosBaseApi = axios.create({
  baseURL: 'http://localhost:81/portal_req_backend/public/api/',
   headers : {
    'Accept': 'application/json',
  },

  withCredentials: false
});