<?php //print_r($this->session->userdata); ?> 
<!-- Main navbar -->
<?php if(session()->get("empname") =='') {  ?>  <!-- Refer login controller for session ['admin_name']should be defined before its used -->
<div class="navbar navbar-inverse bg-success-300">
  <div class="navbar-header"> <a class="navbar-brand text-bold" href="javascript:;" style="text-transform: uppercase;"><strong>IT Application Request System</strong></a> </div>
</div>
<?php } else { ?>

<!-- Main navbar -->
<div class="navbar navbar-inverse bg-success-300">
  <div class="navbar-header"> <a class="navbar-brand" href="javascript:;" style="text-transform:uppercase;text-align:center;"><strong>IT Application Request System</strong></a> </div>
  
  <div class="navbar-collapse collapse" id="navbar-mobile">
  
    <ul class="nav navbar-nav navbar-right">
     
	 <li><a href="#"><i class="icon-user-tie"></i> <span class="visible-xs-inline-block position-left"></span></a></li>
	 
	 <li class="dropdown dropdown-user"> <a class="dropdown-toggle" data-toggle="dropdown"><span><strong> WELCOME&nbsp;&nbsp;&nbsp;<?php echo session()->get("empname");?></span> <i class="caret"></strong></i> </a>
        <ul class="dropdown-menu dropdown-menu-right">
          <li><a href="<?php echo config('app.site_url').'/logout'?>"><i class="icon-switch2"></i> Logout</a></li>
        </ul>
      </li>    
      
    </ul>
  </div>
</div>
<!-- /main navbar --> 
<?php } ?>

<?php /**PATH C:\xampp\htdocs\portal_request\resources\views/layout/header.blade.php ENDPATH**/ ?>