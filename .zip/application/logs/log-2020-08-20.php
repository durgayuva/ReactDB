<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-20 09:18:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:18:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:19:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:19:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:22:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:22:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:24:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:24:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:25:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:25:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:25:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:25:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:26:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-20 09:26:47 --> 404 Page Not Found: Assets/images
