<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-02 08:10:11 --> 404 Page Not Found: Assets/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-02 08:10:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-02 08:10:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-02 08:10:43 --> 404 Page Not Found: Assets/images
