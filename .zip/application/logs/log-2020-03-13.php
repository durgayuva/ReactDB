<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-13 08:16:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-13 08:16:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-13 17:24:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-13 17:24:07 --> 404 Page Not Found: Assets/images
