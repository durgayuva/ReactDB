<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-08 10:45:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 10:45:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 12:54:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 12:54:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 12:59:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 12:59:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 13:56:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 13:56:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 16:06:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-08 16:06:37 --> 404 Page Not Found: Assets/images
