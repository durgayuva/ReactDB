<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-19 15:19:31 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:19:31 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:19:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:20:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:20:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:20:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:55:21 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-19 15:55:21 --> 404 Page Not Found: Assets/images
