<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-27 08:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 08:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 08:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 08:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 10:38:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 10:38:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 10:43:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 10:43:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 10:43:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 11:44:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 11:44:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:20:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:20:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:21:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:21:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:22:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:22:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:30:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:30:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:32:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:32:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:37:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:37:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:42:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 12:42:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:16:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:16:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:17:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:17:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:24:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:24:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:49:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:49:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:49:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:49:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 14:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 15:00:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 15:00:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 15:23:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 15:23:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 16:44:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 16:44:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:29:12 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 179
ERROR - 2020-04-27 20:29:15 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 179
ERROR - 2020-04-27 20:29:18 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 179
ERROR - 2020-04-27 20:29:20 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 179
ERROR - 2020-04-27 20:39:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:39:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:40:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:40:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:41:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:41:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:43:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-27 20:43:10 --> 404 Page Not Found: Assets/images
