<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-19 08:18:20 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:18:20 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:33:35 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:33:35 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:34:28 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 08:34:28 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 09:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 09:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 09:49:09 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 09:49:10 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 10:09:15 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 10:09:16 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 10:59:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 10:59:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:23:51 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:23:52 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:24:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:24:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:24:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:24:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:25:01 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:25:01 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:25:14 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-19 16:25:14 --> 404 Page Not Found: Assets/images
