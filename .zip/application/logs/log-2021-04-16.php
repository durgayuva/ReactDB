<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-16 07:22:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-16 07:22:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-16 08:28:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-16 08:28:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-16 10:22:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-16 10:22:34 --> 404 Page Not Found: Assets/images
