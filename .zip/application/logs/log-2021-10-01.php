<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-01 08:22:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-01 08:22:44 --> 404 Page Not Found: Assets/images
