<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-04 14:09:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:09:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:26:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:26:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-04 14:53:51 --> 404 Page Not Found: Assets/images
