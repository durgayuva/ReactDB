<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-12 08:18:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 08:18:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 08:18:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 08:18:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 09:39:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 09:39:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 13:08:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 13:08:47 --> 404 Page Not Found: Assets/images
