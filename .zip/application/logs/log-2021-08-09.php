<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-09 13:40:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 13:40:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 16:32:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 16:32:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 17:26:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 17:26:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 17:26:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-09 17:26:32 --> 404 Page Not Found: Assets/images
