<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-17 08:34:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:34:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:35:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:35:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:35:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:35:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:36:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:36:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:54:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 08:54:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 09:24:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 09:24:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 09:24:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-17 09:24:38 --> 404 Page Not Found: Assets/images
