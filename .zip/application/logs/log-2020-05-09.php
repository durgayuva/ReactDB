<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 08:46:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:46:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:47:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:47:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:58:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:58:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 08:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:00:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:00:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:42:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:42:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:51:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 09:51:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 10:42:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 10:42:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 11:11:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 11:11:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 21:21:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-09 21:21:44 --> 404 Page Not Found: Assets/images
