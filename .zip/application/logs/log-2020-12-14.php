<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 07:53:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 07:53:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 13:57:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 13:57:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-14 14:13:04 --> 404 Page Not Found: Assets/images
