<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-20 13:48:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-20 13:48:54 --> 404 Page Not Found: Assets/images
