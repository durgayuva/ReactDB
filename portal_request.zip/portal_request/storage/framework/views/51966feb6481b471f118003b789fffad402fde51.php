<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>IT APLICATION REQUEST SYSTEM</title>

<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>

</head>
<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<body>

<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-container"> 
<div class="page-content"> 
<div class="sidebar sidebar-main"> <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </div>
<div class="content-wrapper"> 
<div class="breadcrumb-line">
<ul class="breadcrumb">
	<li><a href=""<i class="icon-home2 position-left"></i> Home</a></li> <!-- To Give Space in the class="icon-home2" <i> ..</i> -->
</ul>
</div>

<div class="content"> 
<div class="row" id="blockContent">
<form action="" class="form-horizontal" name="Approval_form" id="Approval_form" enctype="multipart/form-data" method="POST" >	
<div class="panel border-grey-300 panel-bordered">
<div class="panel-heading bg-grey-300">
	<h6 class="panel-title text-captilize"><strong>Approval</strong></h6>
</div>
							
<div class="panel-body">

<?php 	$row = $generalModel->getviewcode(request()->segment(3));  //s print_r($row); 
		$title = $generalModel->getDetails('system_desc','system_desc_master','id='.$row[0]->system_desc_id.'');
		$emp = $generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.$row[0]->requested_by.'" ');
		$projdept = $generalModel->getprojdept($row[0]->system_desc_id);
?>

<table class="table table-bordered">  
		
	<tr>
		<td class="bg-blue" align="left" colspan="4" border="1">&nbsp;<b>View</b></td>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Reference Number</b></td>
		<td style="color:red;"><b><?php echo $row[0]->project_ref_no; ?></b></td>
		<td class="danger" align="right">&nbsp;<b>Feasibility Study</b></td>
		<td colspan="3"><?php echo $row[0]->feasible_status; ?></td>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Requirement Type</b></td>
		<td><?php echo $row[0]->system; ?></td>
		<td class="danger" align="right">&nbsp;<b>Project Developer</b></td>
		<td><?php echo $generalModel->getDetails('cs_emp_name','portal_db.tbl__cs_employee','cs_emp_username = "'.$row[0]->project_developer.'" '); ?></td>
	</tr>	
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Project Title</b></td>
		<td><?php echo $title; ?></td>
		<td class="danger" align="right">&nbsp;<b>Development Days</b></td>
		<?php if($row[0]->dev_days !='0') { ?>
		<td><?php echo $row[0]->dev_days; ?></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Project Department Name</b></td>
		<td><?php echo $projdept[0]->dept_name; ?></td>
		<td class="danger" align="right">&nbsp;<b>Tentative Start Date</b></td>
		<?php if($row[0]->tentative_start_date != '0000-00-00') { ?>
		<td><?php echo date('d-M-Y',strtotime($row[0]->tentative_start_date)); ?></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Current Process</b></td>
		<td><?php echo $row[0]->current_process; ?></td>
		<td class="danger" align="right">&nbsp;<b>Tentative End Date</b></td>
		<?php if($row[0]->tentative_target_date !='') { ?>
		<td><?php echo date('d-M-Y',strtotime($row[0]->tentative_target_date)); ?></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Proposed Process</b></td>
		<td><?php echo $row[0]->proposed_process; ?></td>
		<td class="danger" align="right">&nbsp;<b>Priority</b></td>
		<?php if($row[0]->project_priority !='') { ?>
		<td><?php echo $row[0]->project_priority; ?></td>
		<?php } else { ?>
		<td><?php echo  '-'; ?></td>
		<?php } ?>
	</tr>	
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Select 4FP</b></td>
		<td><?php echo $row[0]->{'4fp'}; ?></td>
		<td class="danger" align="right">&nbsp;<b>Actual Start Date</b></td>
		<?php if($row[0]->project_start_date !='0000-00-00') { ?>
		<td><?php echo date('d-M-Y',strtotime($row[0]->project_start_date)); ?></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Outcome</b></td>
		<td><?php echo $row[0]->outcome; ?></td>
		<td class="danger" align="right">&nbsp;<b>Actual End Date</b></td>
		<?php if($row[0]->dev_completed_date !='0000-00-00') { ?>
		<td><?php echo date('d-M-Y',strtotime($row[0]->dev_completed_date)); ?></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
	</tr>
	
	<tr>
		<td class="danger" align="right">&nbsp;<b>Document</b></td>
		<?php if($row[0]->project_document !='') { ?>
		<td><b><a href="<?php echo config('app.site_url').'/'.'Fileupload/'.$row[0]->project_document;?>" class="btn btn-xs btn-rounded bg-danger-600" target="_new"><i class="icon-download"></i></a></b></td>
		<?php } else { ?>
		<td><?php echo '-'; ?></td>
		<?php } ?>
		<td class="danger" align="right">&nbsp;<b>Raised By</b></td>
		<td><?php echo $emp ; ?></td>
	</tr>
	
</table>

<br/>
	
<table class="table table-bordered">  
	<tr>
		<td class="bg-slate" align="left" colspan="6" border="1">&nbsp;<b>History</b></td>
	</tr>

	<tr class="warning">
		<th><b>SL.NO</b></th>
		<th><b>Comments</b></th>
		<th><b>Status</b></th>
		<th><b>Updated By</b></th>
		<th><b>Updated Date</b></th>
	</tr>
	
	<?php $i=1;
			$status = $generalModel->getstatus_cmts($row[0]->id); 
			foreach($status as $cmt) { 
			$sts_name = $generalModel->Status_Color($cmt->status); 
			$emp = $generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.$cmt->approver_name.'" ');			
	?>
	
	<tr>
		<td><?php echo $i;?></td>
		<?php if($cmt->comment!='') { ?>
		<td><?php echo $cmt->comment;?></td>
		<?php } else { ?>
		<td><?php echo '-' ; ?></td>
		<?php } ?>
		<td><span class="label <?php echo $sts_name[0]->color_code;?>"><?php echo $cmt->status;?></span></td>
		<td><?php echo $emp ;?></td>
		<td><?php echo date('d-M-Y',strtotime($cmt->approved_date));?></td>
	</tr>

<?php $i++; } ?>
			
</table>
		
<br/><br/>


<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" />
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<input type="hidden" id="id" name="id" value="<?php echo $row[0]->id;?>" />
	
<?php if(request()->segment(2) =='hodapprove') {  ?>
<div class="row">
<div class="col-sm-12">
	<div class="form-group">
		<label class="control-label col-sm-1"><strong>Status</strong></label>
		<div class="col-lg-4">
			<label class="radio-inline"> 
				<input type="radio" name="sts" id="sts" class="control-success" value="HODApproved" />Approve
			</label>
			<label class="radio-inline">									
				<input type="radio" name="sts" id="sts" class="control-danger" value="Rerouted to User" />Re-Route
			</label>
		</div>
	</div>
	
	<div class="form-group" id="hodcmt" style="display:none;">
		<label class="control-label col-sm-1"><strong>Comments</strong></label>
		<div class="col-sm-4">
		<textarea class="form-control elastic" name="cmts" id="cmts" placeholder="Enter your comments" ></textarea>     
		</div>
	</div>
	
</div>
</div>

<div class="row">
	<div class="text-center">
		<button type="submit" class="btn btn-xs btn-rounded bg-warning-800" id="approve" name="approve">SUBMIT &nbsp; <i class="icon-flip-vertical2"></i></button>
	</div>
</div>
	
<?php } else if(request()->segment(2) =='feasiview') {  ?>
		
<div class="row">
<div class="col-sm-12">
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-3">
			<label class="radio-inline"> 
				<input type="radio" name="sts" id="sts" class="control-success" value="Yes" />Yes
			</label>
			<label class="radio-inline">									
				<input type="radio" name="sts" id="sts" class="control-primary" value="No" />No
			</label>
			<label class="radio-inline">									
				<input type="radio" name="sts" id="sts" class="control-danger" value="Rerouted to User" />Re-Route
			</label>
		</div>
	</div>
	
	
	<div class="form-group" id="cmtdisp" style="display:none;">
			<label class="control-label col-sm-2"><strong>Comments</strong></label>
			<div class="col-sm-4">
			<textarea class="form-control elastic" name="cmts" id="cmts" placeholder="Enter your comments" ></textarea>     
			</div>
	</div>
	
	<div id="devdisp" style="display:none;">
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Project Developer</strong></label>
		<div class="col-sm-4">
		<select class="" name="devp" id="devp">
			<option></option> 
			<?php $dev = $generalModel->getdevelopers() ; 
				foreach($dev as $itdev) { 
			?>
			<option value="<?php echo $itdev->cs_emp_username;?>" ><?php echo $itdev->cs_emp_name;?></option>
			<?php } ?>
		</select>
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Development Days</strong></label>
		<div class="col-sm-4">
		<input type="text" class="form-control" name="dev_days" id="dev_days" placeholder="Enter Developing Days" />
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Tentative Start Date</strong></label>
		<div class="col-lg-4">
			<input type="text" class="form-control TxtDateField" name="project_date" id="project_date" /> 
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Tentative End Date</strong></label>
		<div class="col-lg-4">
			<input type="text" class="form-control" style="color:red;" readonly name="enddate" id="enddate" value="" /> 
		</div>
	</div>
	
	</div>
	
</div>
</div>

<div class="row">
	<div class="text-center">
		<button type="submit" class="btn btn-xs btn-rounded bg-brown-600" id="approve" name="approve">SUBMIT &nbsp; <i class="icon-flip-vertical2"></i></button>
	</div>
</div>		
		
<?php  } else if(request()->segment(2) =='itapprove') {  ?>

<div class="row">
<div class="col-sm-12">
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-3">
			<label class="radio-inline"> 
				<input type="radio" name="sts" id="sts" class="control-success" value="ITHead Approved" />Approve
			</label>
			<label class="radio-inline">									
				<input type="radio" name="sts" id="sts" class="control-danger" value="Rerouted to User" />Re-Route
			</label>
		</div>
	</div>
	
	<div class="form-group" id="headprio" style="display:none;">
		<label class="control-label col-sm-2"><strong>Priority</strong></label>
			<div class="col-lg-4">
				<select class="" name="itprio" id="itprio">
					<option></option> 
					<option value="High">High</option>
					<option value="Medium">Medium</option>
					<option value="Low">Low</option>
				</select>
			</div>			
	</div>
							
	<div class="form-group" id="itcmt" style="display:none;">
		<label class="control-label col-sm-2"><strong>Comments</strong></label>
			<div class="col-lg-4">
				<textarea class="form-control elastic" name="cmts" id="cmts" placeholder ="Enter your Comments" ></textarea>
			</div>
	</div>
	
</div>
</div>

<div class="row">
	<div class="text-center">
		<button type="submit" class="btn btn-xs btn-rounded bg-brown-600" id="approve" name="approve">SUBMIT &nbsp; <i class="icon-flip-vertical2"></i></button>
	</div>
</div>	

<?php } else if(request()->segment(2) =='projdate') {  ?>

<div class="row">
<div class="col-sm-12">
	
<?php if($row[0]->status =='ITHead Approved') { ?>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Project Start Date</strong></label>
		<div class="col-lg-3">
			<input type="text" class="form-control TxtDateField" name="startdate" id="startdate" /> 
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-5">
		
		<label class="radio-inline"> 
			<input type="radio" name="sts" id="sts" class="control-primary " value="Inprocess" />In Process
		</label>
		
		</div>
	</div>
	
<?php } if (($row[0]->status =='Inprocess') || ($row[0]->status =='Rejected')) {  ?>
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-5">
		<label class="radio-inline"> 
			<input type="radio" name="sts" id="sts" class="control-warning" value="Awaiting for UAT" />Awaiting for UAT
		</label>
		</div>
	</div>

<?php } if($row[0]->status =='Awaiting for UAT') {  ?>
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-5">
		
		<label class="radio-inline"> 
			<input type="radio" name="sts" id="sts" class="control-success" value="UAT Accepted" />UAT Accepted
		</label>
		
		<label class="radio-inline"> 
			<input type="radio" name="sts" id="sts" class="control-danger" value="Rejected" />Rejected
		</label>
		
		</div>
	</div>

	<div class="form-group" id="uatdisp" style="display:none;">
			<label class="control-label col-sm-2"><strong>Remarks</strong></label>
			<div class="col-sm-4">
			<textarea class="form-control elastic" name="cmts" id="cmts" placeholder="Enter your remarks" ></textarea>     
			</div>
	</div>


<?php } if($row[0]->status =='UAT Accepted') { ?>
	
	<div class="form-group">
		<label class="control-label col-sm-2"><strong>Status</strong></label>
		<div class="col-lg-5">
		<label class="radio-inline"> 
			<input type="radio" name="sts" id="sts" class="control-success" value="Completed" />Completed
		</label>
		</div>
	</div>

<?php } ?>
	
</div>
</div>

<?php if($row[0]->status != 'Completed') {  ?> 

<div class="row">
	<div class="text-center">
		<button type="submit" class="btn btn-xs btn-rounded bg-brown-600" id="approve" name="approve">SUBMIT &nbsp; <i class="icon-flip-vertical2"></i></button>
	</div>
</div>	

<?php } } ?>

<div id="display"></div>

</div>
</div>

</form>		
</div>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
</div>
</div>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/autosize.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
		<!-- Line will generate (dash line) will generate while loading -->
		
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/sweet_alert.min.js"></script>  
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/uniform.min.js"></script>
<script src="<?php echo config('app.asset_url');?>/assets/js/bootstrap-datepicker.js"></script>  <!-- TO INCLUDE DATAPICKER -->

<!-- DataTables --> 
<script src="<?php echo config('app.asset_url');?>/assets/js/jquery.datatables.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatables.bootstrap.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/dataTables.buttons.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.flash.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/jszip.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/pdfmake.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/vfs_fonts.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.html5.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.print.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.colVis.min.js"></script>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/validation/validate.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/main.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/custom.js"></script> 

<script>

$(document).ready(function() {
	
$(".TxtDateField").datepicker({    	// TxtDateField ->class name of a datepicker
	format:'dd-M-yyyy',
	autoclose: true,
	//startDate:'0',      // To disable the previous date 
	//endDate:'0',      // To disable the future date 
	todayHighlight:true  
});

$(document).on('change', '#project_date', function() {  
	var noOfDaysToAdd = $("#dev_days").val();    
	var endDate = ""; 
	var count = 0;
	
	var start = $("#project_date").val();  
	var startDate = new Date(start.replace(/-/g, "/"));    
	
	while(count < noOfDaysToAdd){
		var endDate = new Date(startDate.setDate(startDate.getDate() + 1));
		if(endDate.getDay() != 0 && endDate.getDay() != 6) {   //Date.getDay() gives weekday starting from 0(Sunday) to 6(Saturday)  .... Excluding saturday and Sunday
		   count++;
		}
	}
	var data = new Date(endDate);     //You can format this date as per your requirement
	var month = data.toLocaleString('default', { month: 'short' });    //month = data.getMonth();    
	var day = data.getDate();    
	var end = [day,month,data.getFullYear()].join("-");   // alert(end); return false;
	$("#enddate").val(end);
}); 

});

</script>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\portal_request\resources\views/viewEntry.blade.php ENDPATH**/ ?>