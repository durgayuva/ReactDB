<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-28 11:43:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-28 11:43:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-28 11:43:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-28 11:43:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-28 14:33:26 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-09-28 14:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-28 14:33:49 --> 404 Page Not Found: Assets/images
