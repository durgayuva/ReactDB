<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 10:30:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-28 10:30:32 --> 404 Page Not Found: Assets/images
