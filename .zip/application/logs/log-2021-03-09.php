<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-09 09:52:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-09 09:52:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-09 10:05:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-09 10:05:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-09 12:33:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-09 12:33:01 --> 404 Page Not Found: Assets/images
