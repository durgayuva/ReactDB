<?php defined('BASEPATH') OR exit('No direct script access allowed');
class request extends CI_Controller {   
	
function __construct() {
parent::__construct();
	$this->load->library('comportal');
	$this->load->model('user_model');
	$this->load->model('Request_Model');
	$this->load->library('form_validation');
	$this->comportal->userlogincheck();
}

// ************* Load functions ************************

public function home() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	
	$this->load->view('dashboard',$data);
}

public function new_request() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('NewEntry',$data);
}

public function editcreation() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('NewEntry',$data);
}

public function myreq() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}		
	
public function hod() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}		

public function feasi() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}

public function report() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}

public function ithead() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function tentdate() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function UAT() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function hodapprove() { 
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function viewcreation() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function reportview() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function feasiview() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function itapprove() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function projdate() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

// ******************* Load Ajax functions ************************

public function ajax_load_Deptchart() {
		$data['val'] = $this->input->post('val');
		$this->load->view('api/load_Deptchart',$data);
}

public function ajax_loadproject_title() { 
	$title = $this->input->post('title');
	$data['Proj_List'] = $this->Request_Model->getproject_list($title); 
}

public function ajaxload_myrecords() { 		
$data['page'] = $this->uri->segment(3);
	
	switch($data['page']) {
		case 1 :
			if(isset($_POST)) {   
				$data['radiotype'] = $this->input->post('radiotype');           
				$data['priority'] = $this->input->post('priority');
			}
			$data['list'] = $this->Request_Model->getMyrecords($data);
		break;	
		
		case 2 :
			$data['list'] = $this->Request_Model->getHodrecords($data);
		break;
		
		case 4 :
			$data['list'] = $this->Request_Model->getFeasirecords($data);
		break;
		
		case 5 :
			$data['list'] = $this->Request_Model->getItHeadrecords($data);
		break;
		
		case 6 :
			$data['list'] = $this->Request_Model->getTargetdate($data);
		break;
		
		case 7 :
			$data['list'] = $this->Request_Model->getUATdata($data);
		break;
				
	}
	$this->load->view('api/load_my_request',$data);
}

public function ajaxLoadreports() {  //print_r($_POST); exit;  
	if(isset($_POST)) {
		$data['radiotype'] = $this->input->post('radiotype');     				
		$data['stats'] = $this->input->post('stats');           
		$data['dept'] = $this->input->post('dept');           
	}
	$data['records'] = $this->Request_Model->getAllrecords($data);
	$this->load->view('api/load_my_report',$data);
}

public function load_Remarks() {
	$data['id'] = $this->input->post('id');  
	$data['page'] = $this->input->post('page');  
	$this->load->view('Remark',$data);
}


// ************ Load Insert functions ********************

public function getRemark() {  //print_r($_POST); exit; 
	$data['id'] = $this->input->post('id');  
	$data['id'] = $this->input->post('id');  
		if($this->input->post('req_type')) {
		$this->form_validation->set_rules('req_type', 'Reqirement type', 'required');
		
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} else {
			$Res= $this->Request_Model->addnew_Creation($data);
			if ($Res == 1) {
			$data['error_message'] = 1;
			} else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}

public function newCreation() {  // print_r($_POST); exit;    
	
	$data['req_type'] = $this->input->post('req_type');		
	$data['proj_title'] = $this->input->post('proj_title');
	$data['existing_name'] = $this->input->post('existing_name');
	$data['cur_process'] = $this->input->post('cur_process');
	$data['pros_process'] = $this->input->post('pros_process');
	$data['sel_4fp'] = $this->input->post('sel_4fp');
	$data['outcome'] = $this->input->post('outcome');
	$data['editId'] = $this->input->post('editId');
	$data['base_url'] = $this->input->post('base_url');
					
	if(isset($_FILES['docu']) && $_FILES['docu']['name']!='') {  
		$file = explode('.',strtolower($_FILES['docu']['name']));     
		$ary = end($file); 
		$tmp = $_FILES['docu']['tmp_name'];
		$filename = $file[0]."_".date('d-M-Y').".".$ary;
		$alert_file = 'Fileupload/'.$filename;
		
		if(move_uploaded_file($tmp,$alert_file)){	
			$data['upload_doc'] = $filename;
		}
	}  
	else {
		$data['upload_doc'] ='';
	}

	if($this->input->post('req_type')) {
		$this->form_validation->set_rules('req_type', 'Reqirement type', 'required');
		
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} else {
			$Res= $this->Request_Model->addnew_Creation($data);
			if ($Res == 1) {
			$data['error_message'] = 1;
			} else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}

public function getReview() {   //print_r($_POST); exit;
	$data['id'] = $this->input->post('id');		
	$data['it_remark'] = $this->input->post('it_remark');
	$data['base_url'] = $this->input->post('base_url');
		
	if($this->input->post('it_remark')) {
		$this->form_validation->set_rules('it_remark', 'Remark', 'required');
			
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} 
		else {
			$Res= $this->Request_Model->getItReview($data);
			if ($Res == 1) {
				$data['error_message'] = 1;
			} 
			else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}
	
public function getApproval() {   // print_r($_POST); exit;
	$data['pages'] = $this->input->post('pages');
	
	switch($data['pages'])  { 
	case 'hodapprove' :  
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->getHOD_Approval($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
		
	break; 
	
	case 'feasiview' :
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['devp'] = $this->input->post('devp');
		$data['dev_days'] = $this->input->post('dev_days');
		$data['project_date'] = $this->input->post('project_date');		
		$data['enddate'] = $this->input->post('enddate');	
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->getFeasibility($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	case 'itapprove' :
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['itprio'] = $this->input->post('itprio');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->geItHeadApproval($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	case 'projdate' :
		$data['startdate'] = $this->input->post('startdate');		
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');		
		$data['id'] = $this->input->post('id');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->geTentativeDate($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	
	}
	
}		

}
?>