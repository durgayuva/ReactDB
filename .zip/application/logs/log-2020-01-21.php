<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-21 13:52:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 13:52:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:41:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:41:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:42:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:42:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:43:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:43:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:44:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:44:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:45:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:45:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:47:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:47:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:50:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:50:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:51:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:51:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:51:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-21 14:51:03 --> 404 Page Not Found: Assets/images
