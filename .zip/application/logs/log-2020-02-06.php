<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-06 09:48:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-06 09:48:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-06 09:50:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-06 09:50:12 --> 404 Page Not Found: Assets/images
