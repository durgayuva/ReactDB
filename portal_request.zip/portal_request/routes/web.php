<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Middleware\SessionClear;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('login');
});

Route::get('/login',[LoginController::class,'login']);
Route::post('/loginvalidate',[LoginController::class,'loginCheck']);
Route::get('/logout',[LoginController::class,'logout'])->middleware(SessionClear::class);
Route::get('/request/home',[HomeController::class,'home'])->middleware(SessionClear::class);
Route::post('/request/ajax_load_Deptchart',[HomeController::class,'ajax_load_Deptchart'])->middleware(SessionClear::class);
Route::get('/request/new_request',[HomeController::class,'new_request'])->middleware(SessionClear::class);
Route::post('/request/newCreation',[HomeController::class,'newCreation'])->middleware(SessionClear::class);
Route::post('/request/ajax_loadproject_title',[HomeController::class,'ajax_loadproject_title'])->middleware(SessionClear::class);
Route::get('/request/myreq',[HomeController::class,'myreq'])->middleware(SessionClear::class);
Route::any('/request/ajaxload_myrecords/{id}',[HomeController::class,'ajaxload_myrecords'])->middleware(SessionClear::class);
Route::any('/request/viewcreation/{id}',[HomeController::class,'viewcreation'])->middleware(SessionClear::class);
Route::any('/request/editcreation/{id}',[HomeController::class,'editcreation'])->middleware(SessionClear::class);
Route::any('/request/hod',[HomeController::class,'hod'])->middleware(SessionClear::class);
Route::any('/request/feasi',[HomeController::class,'feasi'])->middleware(SessionClear::class);
Route::any('/request/feasiview/{id}',[HomeController::class,'feasiview'])->middleware(SessionClear::class);
Route::any('/request/hodapprove/{id}',[HomeController::class,'hodapprove'])->middleware(SessionClear::class);
Route::any('/request/getApproval',[HomeController::class,'getApproval'])->middleware(SessionClear::class);
Route::any('/request/ithead',[HomeController::class,'ithead'])->middleware(SessionClear::class);
Route::any('/request/itapprove/{id}',[HomeController::class,'itapprove'])->middleware(SessionClear::class);
Route::any('/request/tentdate',[HomeController::class,'tentdate'])->middleware(SessionClear::class);
Route::any('/request/projdate/{id}',[HomeController::class,'projdate'])->middleware(SessionClear::class);
Route::any('/request/UAT',[HomeController::class,'UAT'])->middleware(SessionClear::class);
Route::any('/request/report',[HomeController::class,'report'])->middleware(SessionClear::class);
Route::any('/request/ajaxLoadreports',[HomeController::class,'ajaxLoadreports'])->middleware(SessionClear::class);
Route::any('/request/load_Remarks',[HomeController::class,'load_Remarks'])->middleware(SessionClear::class);
Route::any('/request/reportview/{id}',[HomeController::class,'reportview'])->middleware(SessionClear::class);
Route::any('/request/portal_access_request',[HomeController::class,'portal_access_request'])->middleware(SessionClear::class);
Route::any('/request/my_access_request_list',[HomeController::class,'my_access_request_list'])->middleware(SessionClear::class);
Route::any('request/portal_access_view/{id}/{name}',[HomeController::class,'portal_access_view'])->middleware(SessionClear::class);
Route::any('/request/submit_to_approve',[HomeController::class,'submit_to_approve'])->middleware(SessionClear::class);
Route::any('/request/save_ROApproval',[HomeController::class,'save_ROApproval'])->middleware(SessionClear::class);
Route::any('/request/get_approval_list',[HomeController::class,'get_approval_list'])->middleware(SessionClear::class); 
Route::any('/request/get_IT_approval_list',[HomeController::class,'get_IT_approval_list'])->middleware(SessionClear::class);
Route::any('/request/save_ITApproval',[HomeController::class,'save_ITApproval'])->middleware(SessionClear::class);
Route::any('/request/getReview',[HomeController::class,'getReview'])->middleware(SessionClear::class);


