<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>IT APPLICATION REQUEST SYSTEM</title>

<!-- Global stylesheets starts -->
	
<!-- To get the arrow mark below the log out button -->
<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
<!-- Global stylesheets ends -->

<!-- Core JS files starts -->
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>
<!-- Core JS files ends -->

<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="<?php echo config('app.asset_url');?>/assets/css/datatables.bootstrap.min.css"/>
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/buttons.dataTables.min.css">

</head>
<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<body>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-container"> 
<div class="page-content"> 
<div class="sidebar sidebar-main"> <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </div>
 <div class="content-wrapper"> 
<div class="breadcrumb-line">
<ul class="breadcrumb">
	<li><a href=""<i class="icon-home2 position-left"></i> Home</a></li> <!-- To Give Space in the class="icon-home2" <i> ..</i> -->
</ul>
</div>

<div class="content"> 
<div class="row" id="blockContent">
<form action="" class="form-horizontal" name="portal_access_request_form" id="portal_access_request_form" enctype="multipart/form-data" method="POST" >
							
<div class="panel border-blue panel-bordered">
<div class="panel-heading bg-blue">
	<h6 class="panel-title text-captilize"><strong>Portal Access Request List - <?php echo $pageTitle; ?></strong></h6>
</div>
							
<div class="panel-body"> 
	
<?php //$editrequest = $this->Request_Model->getviewcode($this->uri->segment(3));  //  print_r($editrequest ); ?>

<input type="hidden" id="pages" name="pages" value="<?php //echo $this->uri->segment(2);?>" />
<input type="hidden" id="editId" name="editId" value="<?php //echo $editrequest['id'];?>" />

<div class="row">
	<div class="col-md-12">
		<div class="table-responsive">
			<table class="table table-responsive table-bordered" id="tblList">
				<thead>
					<tr class="bg-brown-300">
						<th>Sl.No</th>
						<th>Action</th>
						<th>Status</th>
						<th>Portal List</th>
						<th>Remarks</th>
						<th>Created By</th>
						<th>Created Date</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1; if(count($p_access_list)>0) {
						foreach($p_access_list as $plist):?>
						<tr>
							<td><?php echo $i; ?></td>
							<td align="center"><a href="javascript:void(0);" title="View" onClick="Request_AjaxViewDetails(<?php echo $plist->access_id; ?>,<?php echo "'".request()->segment(2)."'"; ?>)"><i class="icon-eye"></i></a></td>
							<?php $text ='';
							$names = $generalModel->getUserName($plist->route_to);
							$class ='';
							if($plist->status=='S'){
								$text = 'Awaiting Approval  <br/>'.$names[0]->cs_emp_name;
								$class="label label-info";
							} else if($plist->status=='HA') {
								$text = 'Awaiting IT Approval  <br/>Portal Team';
								$class="label label-default";
							} else if($plist->status=='C') {
								$text = 'Completed';
								$class="label label-success";
							} else {
								$text = 'Rejected';
								$class="label label-danger";
							}?>
							<td align="center"><span class="<?php echo $class;?>"><?php echo $text; ?></span></td>
							<td><?php echo $plist->portal_list; ?></td>
							<td><?php echo $plist->remarks; ?></td>
							<?php $text ='';
							$namesData = $generalModel->getUserNameByEmpID($plist->created_by);
							?>
							<td><?php echo isset($namesData[0]->cs_emp_name) ? $namesData[0]->cs_emp_name : '-'; ?></td>
							<td><?php echo date('d/M/Y H:i:s A',strtotime($plist->created_date)); ?></td>
						</tr>
					<?php $i++; endforeach; } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
									
<div id="display"></div>
		
<?php  if(isset($error_message)) {  ?>
	<div class="alert alert-danger alert-bordered"> <span class="text-semibold"><?php echo $error_message;?></span> 
	</div>
 <?php  } ?>

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" /> 							
	 
</div>
</div>
</div>
</form>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>			
</div>
</div>
</div>
</div>
<!-- Modal Box -->
<div id="modal_view_content" class="modal fade" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" style="width:60%;">
    <div class="modal-content" id="blockUI">
      <div class="modal-header bg-info">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">View Portal Access Details</h4>
      </div>
      <div class="modal-body">
        	Loading......
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- /End Modal Box -->	
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/autosize.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
		<!-- Line will generate (dash line) will generate while loading -->
		
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/sweet_alert.min.js"></script>  
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/uniform.min.js"></script>

<!-- DataTables --> 
<script src="<?php echo config('app.asset_url');?>/assets/js/jquery.datatables.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatables.bootstrap.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/dataTables.buttons.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.flash.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/jszip.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/pdfmake.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/vfs_fonts.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.html5.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.print.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.colVis.min.js"></script>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/validation/validate.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/custom.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/main.js"></script> 

<script>
	$('#tblList').DataTable();
	
function Request_AjaxViewDetails(id,uriSegment)
{
	var baseurl =$("#base_url").val();
	$('#modal_view_content').modal('show', {backdrop: 'static'});

	$.ajax({
		url: baseurl+"request/portal_access_view/"+id+"/"+uriSegment,
		success: function(response)
		{ 
			$('#modal_view_content .modal-body').html(response);
		}
	});
}
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\portal_request\resources\views/portal_access_list.blade.php ENDPATH**/ ?>