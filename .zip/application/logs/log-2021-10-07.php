<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-07 09:09:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-07 09:09:34 --> 404 Page Not Found: Assets/images
