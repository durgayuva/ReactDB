@inject('generalModel','App\Models\GeneralModel')
@inject('userModel','App\Models\UserModel')
<table class="table table-bordered">
	<tr class="bg-primary-300">
		<td colspan="4"><strong>Portal Access Request Details</strong></td>                 
	</tr>
	<tr>
		<th><strong>Portal List</strong></th>
		<th><?php echo $rqDetails[0]->portal_list;?></th>
		<th><strong>Remarks</strong></th>
		<th><?php echo $rqDetails[0]->remarks;?></th>
	</tr>
</table>
<br></br>
<table class="table table-bordered">
	<tr class="bg-primary-300">
		<td colspan="4"><strong>Approval Histroy</strong></td>                 
	</tr>
	<tr class="">
		<td><strong>Date</strong></td>
		<td><strong>Name</strong></td>
		<td><strong>Status</strong></td>
		<td><strong>Comments</strong></td>
	</tr>
	<?php if(count($commentsDetails)>0) { 
		foreach($commentsDetails as $row) :?>
		<tr>
			<td>
				<?php if($row->approved_date!=NULL && $row->approved_date!='0000-00-00'){ echo date('d-M-Y',strtotime($row->approved_date)); } else {echo '-';} ?>
			</td>
			<td><?php echo $row->approver_name; ?></td>
			<?php $text ='';
				$class ='';
				if($row->status=='S'){
					$text = 'Awaiting RO/HOD Approval';
					$class="label label-info";
				} else if($row->status=='HA'){
					$text = 'Awaiting Portal Team Approval';
					$class="label label-default";
				} else if($row->status=='C'){
					$text = 'Completed';
					$class="label label-success";
				} else {
					$text = 'Rejected';
					$class="label label-danger";
				} ?>
				<td align="center"><span class="<?php echo $class;?>"><?php echo $text; ?></span></td>
            <td><?php echo $row->comment; ?></td>
		</tr>
	<?php endforeach; } ?>
</table>
<br/><br/>

<?php if($urisegment == "get_approval_list" && $rqDetails[0]->status == 'S') {?>
	<form name="frmHODSubmit" id="frmHODSubmit" class="form-horizontal form-validate-jquery" method="post" enctype="multipart/form-data" action="#">
		<div class="row">
			<div class="col-sm-8">
				<div id="divEditPortal" class="form-group">
					<label class="control-label col-sm-3"><strong>Portal List</strong></label>
					<div class=""><textarea class="form-control elastic" name="portal_name" id="portal_name" style="width:260px;"><?php echo $rqDetails[0]->portal_list;?></textarea></div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<input type="hidden" name="access_id" id="access_id" value="<?php if(isset($rqDetails[0]->access_id)) { echo $rqDetails[0]->access_id;} else { echo "";}?>"/>
				<input type="hidden" name="base_url" id="base_url" value="<?php echo config('app.asset_url'); ?>"/>
				<div class="form-group"  id="statusContainer">
					<label class="control-label col-sm-3"><strong>Status</strong><span class="text-danger">*</span></label>
					<label class="radio-inline"> 
					<input type="radio" name="status" id="status" class="control-success" value="HA" />Approve
					</label>
					<label class="radio-inline">									
					<input type="radio" name="status" id="status" class="control-danger" value="R-HA" />Reject
					</label>
				</div>
			</div>
			
			<div class="col-sm-6">
				<div class="form-group">
					<label class="control-label col-sm-3"><strong>Comments</strong><span class="text-danger">*</span></label>
					<div class="col-sm-8">
					<textarea class="form-control elastic" name="cmts" id="cmts" placeholder="Enter your comments" style="text-transform:uppercase;"></textarea>     
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="text-center">
				<button type="submit" class="btn btn-xs btn-rounded bg-brown-800" id="hod_approval" name="hod_approval">Submit <i class=" icon-loop3"></i></button>
			</div>
		</div>
	</form>
<?php }?>

<?php if($urisegment == "get_IT_approval_list" && $rqDetails[0]->status == 'HA') {?>
	<form name="frmITSubmit" id="frmITSubmit" class="form-horizontal form-validate-jquery" method="post" enctype="multipart/form-data" action="#">
		<div class="row">
			<div class="col-sm-6">
				<input type="hidden" name="access_id" id="access_id" value="<?php if(isset($rqDetails[0]->access_id)) { echo $rqDetails[0]->access_id;} else { echo "";}?>"/>
				<input type="hidden" name="base_url" id="base_url" value="<?php echo config('app.site_url'); ?>"/>
				<div class="form-group"  id="statusContainer">
					<label class="control-label col-sm-3"><strong>Status</strong><span class="text-danger">*</span></label>
					<label class="radio-inline"> 
					<input type="radio" name="status" id="status" class="control-success" value="C" />Approve
					</label>
					<label class="radio-inline">									
					<input type="radio" name="status" id="status" class="control-danger" value="R-IT" />Reject
					</label>
				</div>
			</div>
			
			<div class="col-sm-6">
				<div class="form-group">
					<label class="control-label col-sm-3"><strong>Comments</strong><span class="text-danger">*</span></label>
					<div class="col-sm-8">
					<textarea class="form-control elastic" name="cmts" id="cmts" placeholder="Enter your comments" style="text-transform:uppercase;"></textarea>     
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="text-center">
				<button type="submit" class="btn btn-xs btn-rounded bg-brown-800" id="it_approval" name="it_approval">Submit <i class=" icon-loop3"></i></button>
			</div>
		</div>
	</form>
<?php }?>

<script>
$(document).on('click', '#hod_approval', function(e) {   
	var base_url = $('#base_url').val();
	$("#frmHODSubmit").validate({	
		ignore: '.select2-input', // ignore hidden fields
        errorClass: 'validation-error-label',
        successClass: 'validation-valid-label',
        highlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
        unhighlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
		
		rules: {
            status: {
                required: true
            },
			cmts: {
				required: true
			}
        },
        errorPlacement: function(error, element)
        {
			if (element.attr("type") == "radio"){
				error.appendTo( element.parents('#statusContainer') );
			}
			else{
				error.insertAfter(element);
			}			
        },
		validClass: "validation-valid-label",
        /*success: function(label) {
			//$(".new_entry_btn").hide();
            label.removeClass("validation-error-label")
        },*/
		submitHandler: function(form,e) { 
			e.preventDefault();
			var ok = confirm("Are you sure you want to submit?");
			if (ok == true) {
				var data = new FormData(form);
				$.ajax({
					url: base_url+"request/save_ROApproval",
					type:"post",
					data:data,
					headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
					enctype: 'multipart/form-data',
					//mimeType:"multipart/form-data",
					contentType: false,
					cache: false,
					processData: false,
					error:function(data){
						alert ("An Error has Occured...");
						console.log(data);
						$('div#blockUI').unblock();
						return false;
					},
					beforeSend: function() {
						$('#blockUI').block({ 
							message: '<span class="text-semibold"><i class="icon-spinner4 spinner position-left"></i>&nbsp; Processing....</span>',
							overlayCSS: {
								backgroundColor: '#fff',
								opacity: 0.8,
								cursor: 'wait'
							},
							css: {
								border: 0,
								padding: '10px 15px',
								color: '#fff',
								width: 'auto',
								'-webkit-border-radius': 2,
								'-moz-border-radius': 2,
								backgroundColor: '#333'
							}
						});
					},
					success: function(response)
					{
						if(response==1){
							$('div#blockUI').unblock();
							var status = $("input[type='radio'][name='status']:checked").val();
							var message = "";
							if(status == "HA") {
								message = "Approved Successfully";
							} else {
								message = "Reject Successfully";
							}
							alert(message);
							window.location.href = base_url+"/request/get_approval_list";
						}
					}
				});
				return false;
			}			
		}
	})
});


/* IT Approval */
$(document).on('click', '#it_approval', function(e) {   
	var base_url = $('#base_url').val();
	$("#frmITSubmit").validate({	
		ignore: '.select2-input', // ignore hidden fields
        errorClass: 'validation-error-label',
        successClass: 'validation-valid-label',
        highlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
        unhighlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
		
		rules: {
            status: {
                required: true
            },
			cmts: {
				required: true
			}
        },
        errorPlacement: function(error, element)
        {
			if (element.attr("type") == "radio"){
				error.appendTo( element.parents('#statusContainer') );
			}
			else{
				error.insertAfter(element);
			}			
        },
		validClass: "validation-valid-label",
        /*success: function(label) {
			//$(".new_entry_btn").hide();
            label.removeClass("validation-error-label")
        },*/
		submitHandler: function(form,e) { 
			e.preventDefault();
			var ok = confirm("Are you sure you want to submit?");
			if (ok == true) {
				var data = new FormData(form);
				$.ajax({
					url: base_url+"request/save_ITApproval",
					type:"post",
					data:data,

					headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
					enctype: 'multipart/form-data',
					//mimeType:"multipart/form-data",
					contentType: false,
					cache: false,
					processData: false,
					error:function(data){
						alert ("An Error has Occured...");
						console.log(data);
						$('div#blockUI').unblock();
						return false;
					},
					beforeSend: function() {
						$('#blockUI').block({ 
							message: '<span class="text-semibold"><i class="icon-spinner4 spinner position-left"></i>&nbsp; Processing....</span>',
							overlayCSS: {
								backgroundColor: '#fff',
								opacity: 0.8,
								cursor: 'wait'
							},
							css: {
								border: 0,
								padding: '10px 15px',
								color: '#fff',
								width: 'auto',
								'-webkit-border-radius': 2,
								'-moz-border-radius': 2,
								backgroundColor: '#333'
							}
						});
					},
					success: function(response)
					{
						if(response==1){
							$('div#blockUI').unblock();
							var status = $("input[type='radio'][name='status']:checked").val();
							var message = "";
							if(status == "C") {
								message = "Approved Successfully";
							} else {
								message = "Reject Successfully";
							}
							alert(message);
							window.location.href = base_url+"/request/get_IT_approval_list";
						}
					}
				});
				return false;
			}			
		}
	})
});
</script>