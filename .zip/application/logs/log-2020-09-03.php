<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 09:16:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 09:16:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 10:00:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 10:00:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 10:03:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 10:03:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 11:31:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 11:31:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 21:12:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-03 21:12:17 --> 404 Page Not Found: Assets/images
