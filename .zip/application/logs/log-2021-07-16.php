<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-16 08:18:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-16 08:18:59 --> 404 Page Not Found: Assets/images
