<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-28 10:13:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-28 10:13:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-28 10:17:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-28 10:17:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-28 10:19:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-28 10:19:59 --> 404 Page Not Found: Assets/images
