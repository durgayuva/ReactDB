<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-31 10:17:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:17:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:22:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:22:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:28:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:28:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:31:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:31:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:34:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 10:34:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 15:49:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 15:49:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-31 15:50:05 --> 404 Page Not Found: Assets/images
