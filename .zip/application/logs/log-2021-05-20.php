<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-20 10:14:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-20 10:14:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-20 10:42:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-20 10:42:07 --> 404 Page Not Found: Assets/images
