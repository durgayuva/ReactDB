<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-19 08:21:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 08:21:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 08:25:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 08:25:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:46:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:46:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:48:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:48:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:48:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:48:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:51:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 11:51:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 13:51:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-19 13:51:18 --> 404 Page Not Found: Assets/images
