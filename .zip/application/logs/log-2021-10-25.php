<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 09:10:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-25 09:10:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-25 09:38:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-25 09:38:41 --> 404 Page Not Found: Assets/images
