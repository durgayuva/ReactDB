<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-28 07:26:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-28 07:26:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-28 09:35:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-28 09:35:51 --> 404 Page Not Found: Assets/images
