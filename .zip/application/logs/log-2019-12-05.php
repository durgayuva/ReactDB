<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-05 08:00:49 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 08:00:50 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 09:27:42 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 09:42:16 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 09:42:17 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 12:06:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 12:06:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:02:55 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:02:55 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:03:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:03:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:03:52 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 14:03:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 16:45:05 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 16:45:05 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 16:46:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-05 16:46:25 --> 404 Page Not Found: Assets/images
