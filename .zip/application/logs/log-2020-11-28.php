<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-28 22:36:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:36:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:37:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:37:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:37:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:37:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:39:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-28 22:39:04 --> 404 Page Not Found: Assets/images
