<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-04 09:07:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-04 09:07:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-04 09:08:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-04 09:08:46 --> 404 Page Not Found: Assets/images
