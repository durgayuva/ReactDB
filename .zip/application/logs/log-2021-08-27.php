<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-27 09:21:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 09:21:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 09:24:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 09:24:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:44:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:44:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:45:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:45:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 11:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 12:08:09 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-27 12:08:10 --> 404 Page Not Found: Assets/images
