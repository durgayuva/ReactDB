<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-25 10:09:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 10:09:08 --> 404 Page Not Found: Assets/images
