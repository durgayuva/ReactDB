<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-02 12:13:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-02 12:13:33 --> 404 Page Not Found: Assets/images
