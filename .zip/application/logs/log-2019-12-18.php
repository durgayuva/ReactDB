<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-18 14:36:01 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-18 14:36:01 --> 404 Page Not Found: Assets/images
