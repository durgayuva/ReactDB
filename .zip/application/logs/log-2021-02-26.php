<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 08:15:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-26 08:15:45 --> 404 Page Not Found: Assets/images
