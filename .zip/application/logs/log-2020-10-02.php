<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-02 12:41:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-02 12:41:28 --> 404 Page Not Found: Assets/images
