<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-18 12:14:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-18 12:14:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-18 12:16:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-18 12:16:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-18 13:34:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-18 13:34:38 --> 404 Page Not Found: Assets/images
