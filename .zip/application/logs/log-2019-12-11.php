<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-11 11:24:12 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-11 11:24:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-11 11:24:18 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-11 11:24:19 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-11 11:43:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-11 11:43:37 --> 404 Page Not Found: Assets/images
