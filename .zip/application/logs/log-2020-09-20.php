<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-20 16:46:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-20 16:46:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-20 16:48:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-20 16:48:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-20 16:52:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-09-20 16:52:36 --> 404 Page Not Found: Assets/images
