<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 12:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:18:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:18:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:21:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:21:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:28:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:28:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:34:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:34:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:36:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-27 12:36:27 --> 404 Page Not Found: Assets/images
