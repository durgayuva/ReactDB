<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-09 15:54:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 15:54:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 16:15:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 16:15:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 17:27:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 17:27:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 17:27:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-11-09 17:27:50 --> 404 Page Not Found: Assets/images
