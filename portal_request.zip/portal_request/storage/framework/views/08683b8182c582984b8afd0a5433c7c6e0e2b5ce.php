<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<div class="table-responsive">
<table class="table table-bordered table-xxs bordered table-striped dataTable no-footer" id="dataTables">
<thead>
<tr class="bg-warning-300">
	<th>Sl.No.</th>
	<th>Ticket No</th>
	<th>Requested By</th>
	<th>Department</th>
	<th>Type</th>
	<th>Project Title</th>
	<th>Assigned To</th>
	<th>Tentative Target Date</th>
	<th>Actual Target Date</th>
	<th>IT Remark</th>
	<th>Status</th>
	<th>Action</th>
</tr>
	
</thead>
     
<tbody>
<?php  if(count($records) > 0) { 
	$j=1; 
	foreach($records as $row) {       //print_r($row); exit;
		$emp = $generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.$row->requested_by.'" ');  
		$dept = $generalModel->getRaiseddept($row->requested_by); 
		$title = $generalModel->getDetails('system_desc','system_desc_master','id='.$row->system_desc_id.''); 
		$assigned = (isset($row->project_developer)) ? $generalModel->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username ="'.$row->project_developer.'"') : ''; 
		$sts_name = $generalModel->Status_Color($row->status);
		$sts_app = $generalModel->status_aaproval($row->id); 
	?>      
	
<tr>
	<td><?php echo $j;?></td>
	<td><?php echo $row->project_ref_no; ?></td>
	<td><?php echo $emp; ?></td>
	<td><?php echo $dept; ?></td>
	<td><?php echo $row->system;?></td>
	<td><?php echo $title; ?></td>
	<td><?php echo $assigned; ?></td>
	<?php if(isset($row->tentative_target_date) && $row->tentative_target_date != '0000-00-00' && $row->tentative_target_date != '1970-01-01') { ?>
	<td><?php echo date('d-M-Y',strtotime($row->tentative_target_date)); ?></td>
	<?php } else { ?>
	<td><?php echo '-'; ?></td>
	<?php } ?>
	<?php if(isset($row->project_completed_date) && $row->project_completed_date != '0000-00-00' && $row->project_completed_date != '1970-01-01') { ?>
	<td><?php echo date('d-M-Y',strtotime($row->project_completed_date)); ?></td>
	<?php } else { ?>
	<td><?php echo '-'; ?></td>
	<?php } ?>
	<td><?php echo $row->it_review_comments; ?></td>
	
	<td><span class="label <?php echo $sts_name[0]->color_code;?>"><?if(($row->status!='Completed') && ($row->status !='Rejected') && ($row->status !='Hold'))  { echo $sts_name[0]->status_history.'<br/>('.$sts_app.')' ; } else { echo $sts_name[0]->status_history; } ?></span></td>
	
	<td nowrap>
		<a href="<?php echo config('app.site_url').'/request/reportview/'.$row->id;?>" class="btn btn-rounded btn-xs bg-teal-600" target="_blank"><i class="icon-book-play"></i></a>
		&nbsp;&nbsp;
		
		<?php if((in_array(session()->get('empname'), config('app.feasi'))) || (in_array(session()->get('empname'), config('app.itheadname'))) ) { 
			
			if( ($row->status !='Submitted') && ($row->status !='HODApproved') && ($row->status !='Rerouted to User') && ($row->status !='Rejected') && ($row->status !='Completed') && ($row->status !='Hold') )  { ?>
		 <button type='button' class='btn bg-danger-300 btn-xs btn-rounded' data-toggle='modal' data-target='#showdefault' onclick="getremark(<?php echo $row->id;?>);" >HOLD ON</button>
		
		<?php }  } ?>
		
	</td>
		
</tr>
 
<?php  $j++; }} else { ?>              
	
<tr>
	<td colspan="12" style="color:red;"> No row Found </td>
</tr> 
<? } ?>
		
</tbody>
</table>
</div>

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>" /> 

<div id="showdefault" class="modal fade">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
			<div class="modal-header bg-blue-300">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h5 class="modal-title">REMARKS</h5>
			</div>
            <div class="modal-body">
      
			</div>
        </div>
    </div>
</div>

<script>

function getremark(id) { 
	var base_url =$("#base_url").val();
	var page =$("#pages").val();
	var dataString ="id="+id+"&page="+page;    
   
	var promise= sendAjaxFunction(base_url +"/request/load_Remarks",dataString); 
		promise.success(function(data){  
			$("#showdefault .modal-body").html(data);
			return false;
		});
	return false;
}

</script><?php /**PATH C:\xampp\htdocs\portal_request\resources\views/api/load_my_report.blade.php ENDPATH**/ ?>