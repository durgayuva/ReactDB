<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-05 14:21:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 14:21:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 15:37:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 15:37:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 15:37:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 15:37:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 16:34:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-05 16:34:13 --> 404 Page Not Found: Assets/images
