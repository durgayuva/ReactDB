<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-08 09:01:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:01:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:04:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:04:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:08:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:08:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:52:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:52:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:58:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-08 09:58:51 --> 404 Page Not Found: Assets/images
