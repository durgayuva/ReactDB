<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 11:53:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-01 11:53:59 --> 404 Page Not Found: Assets/images
