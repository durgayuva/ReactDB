<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-21 11:32:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-21 11:32:51 --> 404 Page Not Found: Assets/images
