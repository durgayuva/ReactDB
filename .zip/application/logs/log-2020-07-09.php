<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-09 15:00:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-09 15:00:41 --> 404 Page Not Found: Assets/images
