<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-25 17:08:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-25 17:08:37 --> 404 Page Not Found: Assets/images
