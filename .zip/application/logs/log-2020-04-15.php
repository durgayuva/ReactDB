<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-15 15:40:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-15 15:40:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-15 15:40:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-15 15:40:46 --> 404 Page Not Found: Assets/images
