<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-01 10:30:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-01 10:30:30 --> 404 Page Not Found: Assets/images
