<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-23 08:00:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-23 08:00:36 --> 404 Page Not Found: Assets/images
