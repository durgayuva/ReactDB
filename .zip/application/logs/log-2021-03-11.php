<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-11 07:50:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-11 07:50:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-11 08:17:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-11 08:17:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-11 12:38:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-11 12:38:12 --> 404 Page Not Found: Assets/images
