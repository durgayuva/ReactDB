<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-13 09:01:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-13 09:01:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-13 17:57:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-13 17:57:06 --> 404 Page Not Found: Assets/images
