<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 00:59:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 00:59:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 02:15:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 02:15:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:26:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:26:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:26:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:26:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:51:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 09:51:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:01:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:01:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:07:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:07:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:53:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:53:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:59:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:59:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:59:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-14 10:59:54 --> 404 Page Not Found: Assets/images
