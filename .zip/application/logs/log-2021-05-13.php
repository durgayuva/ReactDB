<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-13 16:32:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-13 16:32:03 --> 404 Page Not Found: Assets/images
