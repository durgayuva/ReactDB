<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-16 12:29:32 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-16 12:30:08 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-16 12:30:08 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-16 13:42:23 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-16 13:42:23 --> 404 Page Not Found: Assets/images
