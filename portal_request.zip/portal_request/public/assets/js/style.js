/**
 * (c) 2010-2017 Torstein Honsi
 *
 * License: www.highcharts.com/license
 *
 * Grid-light theme for Highcharts JS
 * @author Torstein Honsi
 */

Highcharts.theme = {
   // colors: ['#f7a35c', '#90ee7e', '#7798BF', '#aaeeee'],
    chart: {
        backgroundColor: {
            linearGradient: [0, 0, 500, 500],
            stops: [
                [0, 'rgb(255, 255, 255)'],
                [1, 'rgb(240, 240, 255)']
            ]
        },
    },
    title: {
        style: {
            color: 'Red',
            font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
        }
    },
  
    legend: {
        itemStyle: {
            font: '9pt Trebuchet MS, Verdana, sans-serif',
            color: 'black'
        },
        itemHoverStyle:{
            color: 'Yellow'
        }   
    }
};

// Apply the theme
Highcharts.setOptions(Highcharts.theme);



