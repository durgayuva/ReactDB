<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 08:14:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 08:14:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 09:33:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 09:33:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 10:35:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 10:35:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 12:08:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-27 12:08:59 --> 404 Page Not Found: Assets/images
