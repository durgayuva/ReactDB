<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-12 11:33:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 11:33:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 17:26:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 17:26:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 17:27:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-12 17:27:52 --> 404 Page Not Found: Assets/images
