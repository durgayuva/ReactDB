<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 16:39:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-27 16:39:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-27 16:41:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-27 16:41:06 --> 404 Page Not Found: Assets/images
