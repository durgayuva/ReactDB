<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-25 19:05:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-25 19:05:06 --> 404 Page Not Found: Assets/images
