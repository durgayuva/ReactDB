<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-21 08:59:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 08:59:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 10:57:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 10:57:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 22:41:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 22:41:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-21 22:46:29 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 225
ERROR - 2020-12-21 22:46:29 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 225
ERROR - 2020-12-21 22:46:33 --> Severity: Notice --> Undefined index: upload_doc D:\htdocs\portal_request\application\models\Request_Model.php 225
