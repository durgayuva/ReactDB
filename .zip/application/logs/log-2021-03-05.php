<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 09:03:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:03:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:13:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:13:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:14:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:22:58 --> Severity: Parsing Error --> syntax error, unexpected ',' D:\htdocs\portal_request\application\models\Request_Model.php 65
ERROR - 2021-03-05 09:23:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITH' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid in 49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2021-03-05 09:23:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITH' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid in 49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2021-03-05 09:23:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITH' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid in 49 ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2021-03-05 09:24:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 09:24:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 12:40:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 12:40:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 13:52:09 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2021-03-05 15:40:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 15:40:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-05 15:43:12 --> 404 Page Not Found: Assets/images
