<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 08:56:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 08:56:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 08:56:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 08:56:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 08:59:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 08:59:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 09:01:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 09:01:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 11:27:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-26 11:27:34 --> 404 Page Not Found: Assets/images
