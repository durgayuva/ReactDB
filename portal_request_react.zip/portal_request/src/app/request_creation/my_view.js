import React,{useState,useEffect} from 'react'
import { useParams } from "react-router-dom";
import {getViewDetailService} from '../services/service'

const RequestView = () => {
    const[dataListProjdet,setDataListProject] = useState([])
    const[dataListRow,setDataListRow] = useState([])
    const params = useParams();
    
    useEffect(()=> {
        getViewDetail(params.id)
    }, [params.id])

    const getViewDetail = async(viewid)=>{
      const viewResp = await getViewDetailService(viewid)
      if(viewResp){
        setDataListProject(viewResp.projdept)
        setDataListRow(viewResp.row)
      }
    }

    console.log(dataListRow,"dataList")

  const data = [{
    "id":1,
    "name":'test'
  }]

  var tableData = data.map(function (obj) {
    
    return <tr>
      <td> {obj.id} </td>
      <td> Fund is not recieved </td>
      <td>
        <label className="badge badge-info">DONE</label>
      </td>
      <td> Dec 5, 2017 </td>
      <td> WD-12345 </td>
    </tr>
  })

  
   
  return (
    <div>
      <div className='row-flex'>
        <div className='col-12 grid-margin'>
          <div className='card'>
            <div className='card-header' style={{backgroundColor:'skyblue'}}>
              <h4 style={{fontSize:'20px'}}>VIEW - REQUEST</h4>
            </div>
            { dataListRow.length > 0 ? 
            <div className='card-body' style={{padding:'10px',backgroundColor:'#e6e9f0',background:'-webkit-linear-gradient(to right, rgba(230,233,240,0.5), rgba(238,241,245,0.5))',background:'linear-gradient(to right, rgba(233,202,200,0.5), rgba(238,233,245,0.5))'}}>
              
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Referenece Number :
                </div>
                <div className='col-sm-3' style={{textAlign:'left',color:'red',fontWeight:'bold'}}>
                {dataListRow[0].project_ref_no}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Feasibility Study:
                </div>
                <div className='col-sm-3' style={{textAlign:'left',fontWeight:'bold'}}>
                {dataListRow[0].feasible_status != null ? dataListRow[0].feasible_status : '-'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Requirement Type :
                </div>
                <div className='col-sm-3' style={{textAlign:'left',fontWeight:'bold'}}>
                  { dataListRow[0].system != null ? dataListRow[0].system  : "-"}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Project Developer:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Project Title:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Development Days:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Project Development Name:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Tentative Start Date:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Current Process:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Tentative End Date:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Proposed Process:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Priority:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Select 4fb:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Actual Start Date:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Outcome:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Actual End Date:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
              <div className='row' style={{height:'50px',textAlign:'center',padding:'15px'}}>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}> 
                  Department:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'1234567890'}
                </div>
                <div className='col-sm-3' style={{fontWeight:'bold',textAlign:'right'}}>
                  Raised By:
                </div>
                <div className='col-sm-3' style={{textAlign:'left'}}>
                  {'xcdbsjbbsudbusbu'}
                </div>
              </div>
            </div>: ''}
          </div>
        </div>
      </div>
      <div className="row-flex">
        <div className="col-12 grid-margin">
          <div className="card">
            <div className='card-header' style={{ backgroundColor: 'lightgrey' }}>
              <h4>History</h4>
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table border">
                  <thead style={{ backgroundColor: 'pink' }}>
                    <tr className='border'>
                      <th> SI.No </th>
                      <th> Comments </th>
                      <th> Status </th>
                      <th> Updated By </th>
                      <th> Updated Date </th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableData}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  )

}

export default RequestView
