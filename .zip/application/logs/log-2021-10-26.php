<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-26 12:22:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-26 12:22:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-26 14:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-26 14:41:52 --> 404 Page Not Found: Assets/images
