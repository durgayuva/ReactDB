<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-08 08:22:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 08:22:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 09:49:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 09:49:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 09:58:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 09:58:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:55:05 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:55:05 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:57:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:57:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:58:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-08 13:58:25 --> 404 Page Not Found: Assets/images
