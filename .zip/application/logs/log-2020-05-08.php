<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-08 11:49:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 11:49:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:22:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:41:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:41:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 13:42:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 18:20:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 18:20:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 18:23:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-08 18:23:07 --> 404 Page Not Found: Assets/images
