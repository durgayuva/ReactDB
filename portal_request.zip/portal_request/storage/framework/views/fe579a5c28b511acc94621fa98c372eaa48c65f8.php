
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>IT APPLICATION REQUEST | Login</title>

<!-- Global stylesheets -->

<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">

<!-- /global stylesheets -->

<!-- Core JS files -->
 <script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script>
<!-- Core JS files ends -->

<!-- Theme Js files -->	

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/validation/validate.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script>

<style>
.footer{
	position:relative;
}
</style>
</head>
	
<!-- /theme JS files -->

<body class="bg-slate-800 login-container">  <!-- class="login-container" -> This gives the tiny box for login -->

<!-- <?php  //$layout_header;?> -->
	<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page container -->
	<div class="page-container"> 

		<!-- Page content -->
		<div class="page-content">

			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Content area -->
				<div class="content">
				
				<!-- Form with validation -->
					<form class="form-horizontal" action="" method="post" enctype="multipart/form-data" id="LoginValidation" name="LoginValidation">
						<div class="panel panel-body login-form">
							<div class="text-center">
								<div class="icon-object border-slate-300 text-slate-300"><i class="icon-office"></i></div>
								<h5 class="content-group">Login to Comstar IT Application Request <small class="display-block">Your credentials</small></h5>
							</div>
				
						<div class="form-group has-feedback has-feedback-left">
							<input type="text" class="form-control" placeholder="Username" name="uname" id="uname" required="required">
							<div class="form-control-feedback">
								<i class="icon-user text-muted"></i>
							</div>
						</div>
				
					
						<div class="form-group has-feedback has-feedback-left">
							<input type="password" name="pwd" id="pwd" class="form-control" placeholder="Password">
							<div class="form-control-feedback">
								<i class="icon-lock2 text-muted"></i>
							</div>
						</div>
							
						<div class="form-group" id="showError"></div>
						
						<?php if(isset($error_message)) { ?>
								<div class="alert bg-danger">
									<span class="text-semibold"><?php echo $error_message;?></span>
								</div>
						<?php } ?>
							
						<div class="form-group">
							<button type="submit" name="LoginBtn" id="LoginBtn" class="btn  bg-pink-400 btn-block btn-ladda btn-ladda-progress"  data-style="expand-left" data-spinner-size="20"><span class="ladda-label">Login</span><i class="icon-circle-right2 position-right"></i></button>
						</div> 

						<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" />
						
						</div>
				
				</div>
					</form>
					<!-- /form with validation -->
				</div>
				<!-- /content area -->
			</div>
				<!-- /main content -->

		</div>
		<!-- /page content -->
		<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		 <?php  //$layout_footer;?>
		
	</div>	
	<!-- /page container -->

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/spin.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/ladda.min.js"></script>  	  	

 	
</body>
</html>	<?php /**PATH C:\xampp\htdocs\portal_request\resources\views/login.blade.php ENDPATH**/ ?>