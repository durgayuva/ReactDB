<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-24 08:22:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-24 08:22:55 --> 404 Page Not Found: Assets/images
