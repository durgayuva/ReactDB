<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-23 10:00:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 10:00:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 13:33:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-23 13:33:45 --> 404 Page Not Found: Assets/images
