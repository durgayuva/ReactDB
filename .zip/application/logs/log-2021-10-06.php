<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-06 07:29:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 07:29:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 07:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 07:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 08:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 08:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 08:50:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-06 08:50:17 --> 404 Page Not Found: Assets/images
