<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-04 11:17:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-04 11:17:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-04 14:32:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-04 14:32:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-04 14:32:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-04 14:32:51 --> 404 Page Not Found: Assets/images
