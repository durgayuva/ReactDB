<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-26 15:33:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-26 15:33:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-26 16:17:31 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-26 16:17:31 --> 404 Page Not Found: Assets/images
