<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-12 13:28:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-12 13:28:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-12 14:32:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-12 14:32:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-12 14:33:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-12 14:33:12 --> 404 Page Not Found: Assets/images
