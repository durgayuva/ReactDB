<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-20 08:52:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-20 08:52:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-20 09:30:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-20 09:30:42 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-20 13:29:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-20 13:29:37 --> 404 Page Not Found: Assets/images
