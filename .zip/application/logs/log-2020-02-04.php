<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-04 11:51:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-04 11:51:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-04 11:52:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-04 11:52:12 --> 404 Page Not Found: Assets/images
