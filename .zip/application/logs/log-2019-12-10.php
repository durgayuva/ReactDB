<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-10 08:56:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-10 08:56:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-10 08:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-10 08:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-10 09:02:45 --> 404 Page Not Found: Assets/images
