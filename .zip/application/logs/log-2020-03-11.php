<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-11 09:09:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-11 09:09:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-11 12:33:19 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-03-11 12:33:27 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-03-11 12:34:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-11 12:34:03 --> 404 Page Not Found: Assets/images
