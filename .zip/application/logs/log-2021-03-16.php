<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-16 15:36:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:36:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:36:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:36:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:36:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:36:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:54:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:54:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:55:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 15:55:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 16:06:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-16 16:06:46 --> 404 Page Not Found: Assets/images
