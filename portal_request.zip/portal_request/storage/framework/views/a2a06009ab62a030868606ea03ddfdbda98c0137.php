<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>IT APPLICATION REQUEST SYSTEM</title>

<!-- Global stylesheets starts -->
	
<!-- To get the arrow mark below the log out button -->
<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
<!-- Global stylesheets ends -->

<!-- Core JS files starts -->
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>
<!-- Core JS files ends -->

<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="<?php echo config('app.asset_url');?>/assets/css/datatables.bootstrap.min.css"/>
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/buttons.dataTables.min.css">

</head>
<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<body>
<?php  //$layout_header;?> 
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-container"> 
<div class="page-content"> 
<div class="sidebar sidebar-main"><?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </div>
 <div class="content-wrapper"> 
<div class="breadcrumb-line">
<ul class="breadcrumb">
	<li><a href=""<i class="icon-home2 position-left"></i> Home</a></li> <!-- To Give Space in the class="icon-home2" <i> ..</i> -->
</ul>
</div>

<div class="content"> 
<div class="row" id="blockContent">
<form action="" class="form-horizontal" name="request_form" id="request_form" enctype="multipart/form-data" method="POST" >
							
<div class="panel border-blue panel-bordered">
<div class="panel-heading bg-blue">
	<h6 class="panel-title text-captilize"><strong>Request Creation</strong></h6>
</div>
							
<div class="panel-body"> 
	
<?php $editrequest = $generalModel->getviewcode(request()->segment(3));  //  print_r($editrequest ); ?>

<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<input type="hidden" id="editId" name="editId" value="<?php echo isset($editrequest[0]->id) ? $editrequest[0]->id : '' ;?>" />

<div class="row">
	<div class="col-md-12">

		<div class="form-group">
			<label class="control-label col-sm-3"><strong>Reqirement type</strong></label>
			<div class="col-lg-9">
			<label class="radio-inline"> 
				<input type="radio" name="req_type" id="req_type" class="control-primary sample" value="New One" <?php if(isset($editrequest[0]->system) =="New One") echo "checked";?> />New
			</label>
			<label class="radio-inline">									
				<input type="radio" name="req_type" id="req_type" class="control-danger sample" value="Existing" <?php if(isset($editrequest[0]->system)=="Existing") echo "checked";?> />Existing
			</label>
			</div>
		</div>
		
		<div class="form-group" id="new_system" style="<?php if(isset($editrequest[0]->system) =="New") { ?>display:block;<?php } else { ?>display:none;<?php } ?>">
		<label class="control-label col-sm-3"><strong>Project Title</strong></label>
		
		<div class="col-sm-4"> 
			<input type="hidden" class="form-control" name="test" id="test" value="2"/>
			<input type="hidden" name="projecttitleid" id="projecttitleid" value="<?php echo isset($editrequest[0]->system_desc_id);?>"/>

			<?php if(isset($editrequest[0]->system_desc_id) !='') { ?>
			<input type="text" class="form-control" name="proj_title" id="proj_title" value="<?php echo $generalModel->getdetails('system_desc','system_desc_master','id='.$editrequest[0]->system_desc_id.''); ?>"/>
			<?php } else { ?>
			<input type="text" class="form-control" name="proj_title" id="proj_title"/>
			<?php } ?>
			
			<div id="error_msg"></div>
		</div>
		</div>
									
		<div class="form-group" id="existing_system" style="<?php if(isset($editrequest[0]->system)=="Existing") { ?>display:block;<?php } else { ?>display:none;<?php } ?>">
		<label class="control-label col-sm-3"><strong>System Name</strong></label>
		<div class="col-sm-4">
			<select class="select_tag3" name="existing_name" id="existing_name">
				<option></option> 
					<?php $existingsys = $generalModel->getexisting_system();
						foreach($existingsys as $system){ ?>
						<option value="<?php echo $system->id;?>" <?php if(isset($editrequest->system_desc_id)==$system->id) echo 'selected';?> > <?php echo $system->system_desc;?></option>
					<?php } ?>
			</select>
		</div>	
		</div>
											
		<div class="form-group">
		<label class="control-label col-sm-3"><strong>Current Process</strong></label>
			<div class="col-sm-4">
				<textarea class="form-control elastic" name="cur_process" id="cur_process"><?php echo isset($editrequest[0]->current_process); ?></textarea>
			</div>
		</div>

		<div class="form-group">
		<label class="control-label col-sm-3"><strong>Proposed Process</strong></label>
		<div class="col-sm-4">
			<textarea class="form-control elastic" name="pros_process" id="pros_process"><?php echo isset($editrequest[0]->proposed_process); ?></textarea>
		</div>
		</div>
		
		<div class="form-group">
		<label class="control-label col-sm-3"><strong>Select 4FP</strong></label>
		<div class="col-sm-4">
		<select class="select_tag1" name="sel_4fp" id="sel_4fp">
			<option></option> 
			<option value="Speed" <?php if(isset($editrequest[0]->{'4fp'}) =='Speed') echo 'selected';?> >Speed</option>
			<option value="Quality" <?php if(isset($editrequest[0]->{'4fp'}) =='Quality') echo 'selected';?> >Quality</option>
			<option value="Process" <?php if(isset($editrequest[0]->{'4fp'}) =='Process') echo 'selected';?> >Process</option>
			<option value="Performance" <?php if(isset($editrequest[0]->{'4fp'}) =='Performance') echo 'selected';?> >Performance</option>
		</select>
		</div>
		</div>
		
		<div class="form-group">
		<label class="control-label col-sm-3"><strong>Outcome</strong></label>
		<div class="col-sm-4">
		<select class="select_tag2" name="outcome" id="outcome">
			<option></option> 
			<option value="Time Reduction" <?php if(isset($editrequest[0]->outcome)=='Time Reduction') echo 'selected';?> >Time Reduction</option>
			<option value="Headcount Reduction" <?php if(isset($editrequest[0]->outcome)=='Headcount Reduction') echo 'selected';?>>Headcount Reduction</option>
			<option value="Process Improvement" <?php if(isset($editrequest[0]->outcome)=='Process Improvement') echo 'selected';?>>Process Improvement</option>
			<option value="Cost Improvement" <?php if(isset($editrequest[0]->outcome)=='Cost Improvement') echo 'selected';?>>Cost Improvement</option>
			<option value="Others" <?php if(isset($editrequest[0]->outcome)=='Others') echo 'selected';?> >Others</option>   
		</select>
		</div>
		</div>
		
		<div class="form-group">
		<label class="control-label col-sm-3"><strong>Project Document</strong></label>
		<?php if(isset($editrequest[0]->project_document)!='') {  ?>
		<div class="col-sm-3">
			<input type="file" class="form-control" name="docu" id="docu" />
		</div>
		<input type="hidden" name="proj_doc" id="proj_doc" value="<?php echo isset($editrequest[0]->project_document); ?>" />
	
		<div class="col-sm-2">
			<a href="<?php echo config('app.site_url').'/'.'Fileupload/'.$editrequest[0]->project_document;?>" class="btn btn-rounded btn-xs bg-pink-300" target="_new"><i class="icon-download"></i></a>
		</div>
		<?php } else { ?>
		<div class="col-sm-4">
			<input type="file" class="form-control" name="docu" id="docu" />
		</div>
		<?php } ?>
		</div>
										
		<div class="text-center">
			<button type="submit" class="btn btn-rounded btn-sm bg-danger-800" id="entrybtn" name="entrybtn">Submit &nbsp;<i class="icon-circle-right2"></i></button>
		</div>			
												
	</div>
</div>
									
<div id="display"></div>
		
<?php  if(isset($error_message)) {  ?>
	<div class="alert alert-danger alert-bordered"> <span class="text-semibold"><?php echo $error_message;?></span> 
	</div>
 <?php  } ?>

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" /> 							
	 
</div>
</div>
</div>
</form>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
						
</div>
</div>
</div>
</div>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/autosize.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
		<!-- Line will generate (dash line) will generate while loading -->
		
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/sweet_alert.min.js"></script>  
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/uniform.min.js"></script>

<!-- DataTables --> 
<script src="<?php echo config('app.asset_url');?>/assets/js/jquery.datatables.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatables.bootstrap.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/dataTables.buttons.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.flash.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/jszip.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/pdfmake.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/vfs_fonts.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.html5.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.print.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.colVis.min.js"></script>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/validation/validate.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/custom.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/main.js"></script> 

</body>
</html><?php /**PATH C:\xampp\htdocs\portal_request\resources\views/NewEntry.blade.php ENDPATH**/ ?>