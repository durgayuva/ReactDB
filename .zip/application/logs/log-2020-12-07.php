<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-07 11:41:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-07 11:41:07 --> 404 Page Not Found: Assets/images
