<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-05 13:46:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 13:46:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 13:47:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 13:47:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 13:52:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 13:52:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 15:14:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-05 15:14:13 --> 404 Page Not Found: Assets/images
