<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-07 07:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 07:54:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 07:58:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 07:58:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 15:08:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 15:08:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 22:47:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 22:47:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 22:59:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 22:59:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 23:13:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-07 23:13:41 --> 404 Page Not Found: Assets/images
