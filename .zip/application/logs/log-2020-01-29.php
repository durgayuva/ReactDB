<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-29 18:58:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-29 18:58:40 --> 404 Page Not Found: Assets/images
