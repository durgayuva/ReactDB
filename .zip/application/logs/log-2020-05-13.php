<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 11:04:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:04:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:08:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:08:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:10:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:10:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-13 11:13:55 --> 404 Page Not Found: Assets/images
