<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-01 15:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-01 15:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-01 15:15:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-01 15:15:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-01 15:15:31 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-01 15:15:31 --> 404 Page Not Found: Assets/images
