<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-01 08:25:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 08:25:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 08:25:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 08:25:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 15:18:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 15:18:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 16:26:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-01 16:26:12 --> 404 Page Not Found: Assets/images
