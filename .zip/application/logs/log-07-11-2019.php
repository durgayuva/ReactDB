<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-07 14:40:06 --> 404 Page Not Found: Assets/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-07 14:40:06 --> 404 Page Not Found: Assets/images
