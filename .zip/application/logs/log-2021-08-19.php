<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-19 12:21:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 12:21:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 12:25:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 12:25:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 23:42:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 23:42:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 23:43:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-19 23:43:03 --> 404 Page Not Found: Assets/images
