<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-02 17:10:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-02 17:10:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-02 17:12:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-02 17:12:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-02 17:13:19 --> 404 Page Not Found: Assets/images
