<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-19 08:00:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-19 08:01:00 --> 404 Page Not Found: Assets/images
