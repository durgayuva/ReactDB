
<div class="footer text-muted">
   SONA BLW &copy; <?php echo date("Y");?> Designed &amp; Developed by Sona Comstar IT Systems
</div>