<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<div class="row" id="container5" style="width:auto; height:450px; margin:0 auto">
<?php $list = $generalModel->getstatus(); 
		$colorArr = array('#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#ff5c33','#ffb3ff','#f7a35c','#90ee7e','#80ffbf','#669999','#cc80ff','#D4AF37');  
		$i=0;
	foreach($list as $rows)  { 	
		$stss [] = "'".$rows->status_desc."'";
		
		$value = $generalModel->gethodchart($val,$rows->status_desc); 
		$depdata[] = "{ 
			y:".$value." ,    		
			color :'".$colorArr[$i]."'   
		}";
		$i++;
	}
	$status = implode(',',$stss);  
	$data = implode(',',$depdata);  
?>
</div>

<script type="text/javascript">

$('#container5').highcharts({
   chart: {
		type:'column'
	},
	title:{
        text: 'IT Ticketing - Departmentwise Status'
    },
	yAxis: [{
		min: 0,
		max: 50,
		tickInterval: 5,
		labels: { 
			style: {
				color: 'red',
			}
		},
		lineWidth: 1,
		title: {
			text: 'No. of count',
			style: {
				color: 'green',fontSize:'14px'
			}
		}
	}],
	xAxis: {
        categories: [<? echo $status;?>]
    },
	plotOptions: {
	series: {
		dataLabels:{
		enabled:true,
		color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
		style: {
			textShadow: '0 0 3px black'
		},
		formatter:function(){
			if(this.y > 0)
				return this.y;
		}
		}
	}
	},
	series: [{ 
		data: [<?php echo $data ;?>],    
	}]
}); 
</script><?php /**PATH C:\xampp\htdocs\portal_request\resources\views/api/load_Deptchart.blade.php ENDPATH**/ ?>