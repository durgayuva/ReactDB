<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-07 07:39:42 --> Severity: Notice --> Undefined variable: result D:\htdocs\portal_request\application\controllers\Login.php 37
ERROR - 2021-09-07 07:39:42 --> Severity: Error --> Call to a member function num_rows() on null D:\htdocs\portal_request\application\controllers\Login.php 37
ERROR - 2021-09-07 07:40:07 --> Severity: Notice --> Undefined variable: result D:\htdocs\portal_request\application\controllers\Login.php 37
ERROR - 2021-09-07 07:40:07 --> Severity: Error --> Call to a member function num_rows() on null D:\htdocs\portal_request\application\controllers\Login.php 37
ERROR - 2021-09-07 07:41:47 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-07 07:41:50 --> 404 Page Not Found: Assets/js
ERROR - 2021-09-07 07:41:59 --> Query error: Table 'portal_request.portal_access_request' doesn't exist - Invalid query: SELECT *
FROM `portal_access_request`
ERROR - 2021-09-07 07:42:11 --> Query error: Table 'portal_request.portal_access_request' doesn't exist - Invalid query: SELECT *
FROM `portal_access_request`
WHERE `route_to` = 'intranet'
AND `status` = 'S'
