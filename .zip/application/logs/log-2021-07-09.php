<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-09 09:07:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-09 09:07:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-09 12:29:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-09 12:29:04 --> 404 Page Not Found: Assets/images
