<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 10:15:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 10:15:10 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 10:52:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 10:52:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 14:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 14:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 17:33:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-10 17:33:08 --> 404 Page Not Found: Assets/images
