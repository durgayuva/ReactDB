<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-29 08:30:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:30:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:42:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:42:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:43:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:43:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:43:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 08:43:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:01:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:01:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:01:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:01:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:02:35 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-06-29 09:03:20 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2020-06-29 09:03:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 09:03:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-29 12:05:21 --> 404 Page Not Found: Request/index
