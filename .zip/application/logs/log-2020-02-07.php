<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-07 01:58:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-07 01:58:34 --> 404 Page Not Found: Assets/images
