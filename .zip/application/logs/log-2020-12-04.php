<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-04 10:04:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 10:04:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 10:05:56 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('R&D Online skill Development ', NULL)
ERROR - 2020-12-04 10:06:38 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('R&D Online skill Development ', NULL)
ERROR - 2020-12-04 10:06:39 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('R&D Online skill Development ', NULL)
ERROR - 2020-12-04 10:06:39 --> Query error: Column 'dept_id' cannot be null - Invalid query: INSERT INTO `system_desc_master` (`system_desc`, `dept_id`) VALUES ('R&D Online skill Development ', NULL)
ERROR - 2020-12-04 10:08:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 10:08:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 10:08:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 10:08:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 11:15:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 11:15:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 11:15:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 11:15:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:20:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:20:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:20:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:20:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:21:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-04 16:21:39 --> 404 Page Not Found: Assets/images
