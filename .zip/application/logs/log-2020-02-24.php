<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 14:23:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:23:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:24:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:24:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:24:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:24:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 14:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 17:14:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-24 17:14:04 --> 404 Page Not Found: Assets/images
