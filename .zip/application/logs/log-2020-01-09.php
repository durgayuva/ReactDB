<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-09 10:26:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 10:26:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 15:35:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 15:35:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 15:47:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 15:47:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:10:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:10:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:11:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:11:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:11:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:11:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:13:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:13:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:17:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-09 17:17:05 --> 404 Page Not Found: Assets/images
