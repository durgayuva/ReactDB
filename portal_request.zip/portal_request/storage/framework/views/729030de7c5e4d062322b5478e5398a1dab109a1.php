<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>IT APLICATION REQUEST SYSTEM</title>

<!-- Global stylesheets starts -->

<!-- Global stylesheets starts -->
		
		<!-- To get the arrow mark below the log out button -->
<link href="<?php echo config('app.asset_url');?>/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/core.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo config('app.asset_url');?>/assets/css/minified/colors.min.css" rel="stylesheet" type="text/css">
<!-- Global stylesheets ends -->

<!-- Core JS files starts -->
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/app.js"></script>
<!-- Core JS files ends -->

<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="<?php echo config('app.asset_url');?>/assets/css/datatables.bootstrap.min.css"/>
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo config('app.asset_url');?>/assets/css/buttons.dataTables.min.css">


</head>
<?php $generalModel = app('App\Models\GeneralModel'); ?>
<?php $userModel = app('App\Models\UserModel'); ?>
<body>

<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page container starts -->
<div class="page-container"> 

	<!-- Page content -->
<div class="page-content"> 

	<!-- Main sidebar -->
<div class="sidebar sidebar-main"> <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </div>
    <!-- /main sidebar --> 

  <!-- Main content -->
<div class="content-wrapper"> 
		
	<!-- Page header -->
<div class="breadcrumb-line">
<ul class="breadcrumb">
	<li><a href=""<i class="icon-home2 position-left"></i> Home</a></li> <!-- To Give Space in the class="icon-home2" <i> ..</i> -->
	</ul>
</div>

<div class="content">

<form class="form-horizontal" role="form" method="post" enctype="multipart/form-data" id="Myrequest" name="Myrequest">

<?php $curPage = request()->segment(2); 
	if($curPage=='myreq') {
?>
		
<div class="panel border-danger-300">
<div class="panel-heading bg-danger-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>My Request Screen</strong></h6>
</div>

<div class="panel-body">
	<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />

	<div class="row">
		<div class="col-lg-5">
		<div class="form-group">
			<label class="col-sm-4 control-label-left"><strong>Requirement Type</strong></label>
			<div class="col-sm-8">
				<label class="radio-inline"> 
					<input type="radio" name="req_type" class="control-success req_type" value="" checked />All
				</label>
						
				<label class="radio-inline"> 
					<input type="radio" name="req_type" class="control-danger req_type" value="New one"/>New
				</label>
						
				<label class="radio-inline">									
					<input type="radio" name="req_type" class="control-primary req_type" value="Existing" />Existing
				</label>
			</div>
		</div>
		</div>
						
		<div class="col-lg-4">
		<div class="form-group">
		<label class="col-sm-4 control-label-left"><strong>Priority</strong></label>
			<div class="col-sm-8">
				<select class="" name="priority" id="priority">
					<option></option> 
					<option value="High">High</option>
					<option value="Medium">Medium</option>
					<option value="Low">Low</option>
				</select>
			</div>
		</div>
		</div>
	</div>
										
	<div class="text-center">
		<button type="button" class="btn btn-rounded bg-warning-300 btn_click" id="sub_btn" name="sub_btn" onClick="searchbased();"><strong>Submit <i class=" icon-circle-right2"></i></strong></button> 
	</div>
													
	<hr>
	
	<script>
		$(document).ready(function() {
			LoadMasters();
		});
	</script>
	
	<div id="display"></div>
</div>
</div>
	

<?php  } else if($curPage=='hod') { ?>

<div class="panel border-brown-300">
<div class="panel-heading bg-brown-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>Approval</strong></h6>
</div>
<div class="panel-body">
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<script>
		$(document).ready(function() {
			LoadMasters();
		});
</script>
	
<div id="display"></div>

</div>
</div>

<?php } else if($curPage=='feasi') { ?>

<div class="panel border-teal-300">
<div class="panel-heading bg-teal-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>Feasibility Study</strong></h6>
</div>
<div class="panel-body">
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<script>
		$(document).ready(function() {
			LoadMasters();
		});
</script>
	
<div id="display"></div>

</div>
</div>

<?php } else if($curPage=='ithead') { ?>

<div class="panel border-primary-300">
<div class="panel-heading bg-primary-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>IT Head Approval</strong></h6>
</div>
<div class="panel-body">
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<script>
		$(document).ready(function() {
			LoadMasters();
		});
</script>
	
<div id="display"></div>

</div>
</div>

<?php } else if($curPage=='tentdate') { ?>

<div class="panel border-warning-300">
<div class="panel-heading bg-warning-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>Target Date</strong></h6>
</div>
<div class="panel-body">
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<script>
		$(document).ready(function() {
			LoadMasters();
		});
</script>
	
<div id="display"></div>

</div>
</div>

<?php } else if($curPage=='UAT') {  ?>

<div class="panel border-primary-300">
<div class="panel-heading bg-primary-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>UAT Screen</strong></h6>
</div>
<div class="panel-body">
<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />
<script>
		$(document).ready(function() {
			LoadMasters();
		});
</script>
	
<div id="display"></div>

</div>
</div>

<?php } else if($curPage=='report') {  ?>

<div class="panel border-pink-300">
<div class="panel-heading bg-pink-300 panel-bordered">
	<h6 class="panel-title text-captilize"><strong>Report</strong></h6>
</div>

<div class="panel-body">
	<input type="hidden" id="pages" name="pages" value="<?php echo request()->segment(2);?>" />

	<div class="row">
	
	<?php if(session()->get('empdeptid') == 14) { ?>	
	<div class="col-lg-4">
		<div class="form-group">
		<label class="col-sm-4 control-label-left"><strong>Department</strong></label>
			<div class="col-sm-8">
			<select class="multi" name="multidept[]" id="multidept" multiple="multiple">
				<option value=""></option> 
				<?php $depart =$generalModel->getAlldepartment();
					foreach($depart as $depid){ ?>
				<option value="<?php echo $depid->dept_id;?>" > <?php echo $depid->dept_name;?></option>
				<?php } ?>
			</select>
		</div>
		</div>
	</div>
	
<?php } ?>
		
	<div class="col-lg-4">
		<div class="form-group">
		<label class="col-sm-4 control-label-left"><strong>Status</strong></label>
			<div class="col-sm-8">
				<select class="" name="multists[]" id="multists" multiple="multiple">
					<option value=""></option> 
				<?php $sts = $generalModel->getstatus(); 
					foreach($sts as $val) { 
				?>	
					<option value="<?php echo $val->status_desc; ?>"><?php echo $val->status_desc; ?></option> 
				<?php } ?>
				</select>
			</div>
		</div>
	</div>
	
	<div class="col-lg-4">
		<div class="form-group">
			<label class="col-sm-4 control-label-left"><strong>Requirement Type</strong></label>
			<div class="col-sm-8">
				<label class="radio-inline"> 
					<input type="radio" name="req_type" class="control-success req_type" value="" checked />All
				</label>
						
				<label class="radio-inline"> 
					<input type="radio" name="req_type" class="control-danger req_type" value="New one"/>New
				</label>
						
				<label class="radio-inline">									
					<input type="radio" name="req_type" class="control-primary req_type" value="Existing" />Existing
				</label>
			</div>
		</div>
		</div>
</div>
										
	<div class="text-center">
		<button type="button" class="btn btn-rounded bg-danger-300 btn_click" id="sub_btn" name="sub_btn" onClick="reportbased();"><strong>Submit <i class=" icon-circle-right2"></i></strong></button> 
	</div>
													
	<hr>
	
	<script>
		$(document).ready(function() {
			loadReports();
		});
	</script>
	
	<div id="display"></div>
</div>
</div>

<?php } ?>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</form>
</div>
</div>
</div>

<input type="hidden" id="base_url" name="base_url" value="<?php echo config('app.site_url');?>/" /> 	


<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/blockui.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/autosize.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/pace.min.js"></script>
		<!-- Line will generate (dash line) will generate while loading -->
		
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/sweet_alert.min.js"></script>  
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/select2.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/uniform.min.js"></script>

<!-- DataTables --> 
<script src="<?php echo config('app.asset_url');?>/assets/js/jquery.datatables.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatables.bootstrap.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/dataTables.buttons.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.flash.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/jszip.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/pdfmake.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/vfs_fonts.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.html5.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.print.min.js"></script> 
<script src="<?php echo config('app.asset_url');?>/assets/js/datatable/buttons.colVis.min.js"></script>

<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/js/validation/validate.min.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/script.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/custom.js"></script> 
<script type="text/javascript" src="<?php echo config('app.asset_url');?>/assets/scripts/main.js"></script> 

</body>
</html><?php /**PATH C:\xampp\htdocs\portal_request\resources\views/Master.blade.php ENDPATH**/ ?>