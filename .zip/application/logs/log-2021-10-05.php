<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-05 07:26:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-05 07:26:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-05 07:26:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-05 07:26:27 --> 404 Page Not Found: Assets/images
