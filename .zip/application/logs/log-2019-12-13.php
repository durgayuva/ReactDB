<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-13 08:04:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 08:04:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:54:29 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:54:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:56:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:56:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:57:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:58:47 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 13:58:47 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 14:03:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 14:03:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 15:48:20 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-13 15:48:21 --> 404 Page Not Found: Assets/images
