<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-17 07:57:08 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-17 07:57:32 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 54
ERROR - 2019-12-17 08:10:03 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:10:03 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:10:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:10:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:14:48 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:19:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:19:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:21:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:23:54 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:23:55 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:24:03 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:30:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:30:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:30:43 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 08:30:43 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:13:40 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:13:41 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:17:07 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:17:07 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:17:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:17:46 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-17 09:18:21 --> 404 Page Not Found: Assets/images
