<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 07:13:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 07:13:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 12:22:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 12:22:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 12:45:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 12:45:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 13:38:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 13:38:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 16:42:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 16:42:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 16:42:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-12 16:42:55 --> 404 Page Not Found: Assets/images
