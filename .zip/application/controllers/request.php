<?php defined('BASEPATH') OR exit('No direct script access allowed');
class request extends CI_Controller {   
	
function __construct() {
parent::__construct();
	$this->load->library('comportal');
	$this->load->model('user_model');
	$this->load->model('Request_Model');
	$this->load->library('form_validation');
	$this->comportal->userlogincheck();
}

// ************* Load functions ************************

public function home() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	
	$this->load->view('dashboard',$data);
}

public function new_request() {
	//echo $this->session->userdata('empdeptid');
	//echo $this->user_model->getHOD($this->session->userdata('empdeptid'),'cs_emp_email');
	/*echo "<pre>";
	print_r($this->Request_Model->getUserdet());*/
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('NewEntry',$data);
}

public function editcreation() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('NewEntry',$data);
}

public function myreq() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}		
	
public function hod() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}		

public function feasi() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}

public function report() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);
}

public function ithead() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function tentdate() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function UAT() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('Master',$data);	
}

public function hodapprove() { 
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function viewcreation() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function reportview() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function feasiview() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function itapprove() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

public function projdate() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('viewEntry',$data);
}

// ******************* Load Ajax functions ************************

public function ajax_load_Deptchart() {
		$data['val'] = $this->input->post('val');
		$this->load->view('api/load_Deptchart',$data);
}

public function ajax_loadproject_title() { 
	$title = $this->input->post('title');
	$data['Proj_List'] = $this->Request_Model->getproject_list($title); 
}

public function ajaxload_myrecords() { 		
$data['page'] = $this->uri->segment(3);
	
	switch($data['page']) {
		case 1 :
			if(isset($_POST)) {   
				$data['radiotype'] = $this->input->post('radiotype');           
				$data['priority'] = $this->input->post('priority');
			}
			$data['list'] = $this->Request_Model->getMyrecords($data);
		break;	
		
		case 2 :
			$data['list'] = $this->Request_Model->getHodrecords($data);
		break;
		
		case 4 :
			$data['list'] = $this->Request_Model->getFeasirecords($data);
		break;
		
		case 5 :
			$data['list'] = $this->Request_Model->getItHeadrecords($data);
		break;
		
		case 6 :
			$data['list'] = $this->Request_Model->getTargetdate($data);
		break;
		
		case 7 :
			$data['list'] = $this->Request_Model->getUATdata($data);
		break;
				
	}
	$this->load->view('api/load_my_request',$data);
}

public function ajaxLoadreports() {  //print_r($_POST); exit;  
	if(isset($_POST)) {
		$data['radiotype'] = $this->input->post('radiotype');     				
		$data['stats'] = $this->input->post('stats');           
		$data['dept'] = $this->input->post('dept');           
	}
	$data['records'] = $this->Request_Model->getAllrecords($data);
	$this->load->view('api/load_my_report',$data);
}

public function load_Remarks() {
	$data['id'] = $this->input->post('id');  
	$data['page'] = $this->input->post('page');  
	$this->load->view('Remark',$data);
}


// ************ Load Insert functions ********************

public function getRemark() {  //print_r($_POST); exit; 
	$data['id'] = $this->input->post('id');  
	$data['id'] = $this->input->post('id');  
		if($this->input->post('req_type')) {
		$this->form_validation->set_rules('req_type', 'Reqirement type', 'required');
		
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} else {
			$Res= $this->Request_Model->addnew_Creation($data);
			if ($Res == 1) {
			$data['error_message'] = 1;
			} else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}

public function newCreation() {  // print_r($_POST); exit;    
	
	$data['req_type'] = $this->input->post('req_type');		
	$data['proj_title'] = $this->input->post('proj_title');
	$data['existing_name'] = $this->input->post('existing_name');
	$data['cur_process'] = $this->input->post('cur_process');
	$data['pros_process'] = $this->input->post('pros_process');
	$data['sel_4fp'] = $this->input->post('sel_4fp');
	$data['outcome'] = $this->input->post('outcome');
	$data['editId'] = $this->input->post('editId');
	$data['base_url'] = $this->input->post('base_url');
					
	if(isset($_FILES['docu']) && $_FILES['docu']['name']!='') {  
		$file = explode('.',strtolower($_FILES['docu']['name']));     
		$ary = end($file); 
		$tmp = $_FILES['docu']['tmp_name'];
		$filename = $file[0]."_".date('d-M-Y').".".$ary;
		$alert_file = 'Fileupload/'.$filename;
		
		if(move_uploaded_file($tmp,$alert_file)){	
			$data['upload_doc'] = $filename;
		}
	}  
	else {
		$data['upload_doc'] ='';
	}

	if($this->input->post('req_type')) {
		$this->form_validation->set_rules('req_type', 'Reqirement type', 'required');
		
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} else {
			$Res= $this->Request_Model->addnew_Creation($data);
			if ($Res == 1) {
			$data['error_message'] = 1;
			} else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}

public function getReview() {   //print_r($_POST); exit;
	$data['id'] = $this->input->post('id');		
	$data['it_remark'] = $this->input->post('it_remark');
	$data['base_url'] = $this->input->post('base_url');
		
	if($this->input->post('it_remark')) {
		$this->form_validation->set_rules('it_remark', 'Remark', 'required');
			
		if ($this->form_validation->run() == FALSE) {
			$data['error_message'] = validation_errors();
		} 
		else {
			$Res= $this->Request_Model->getItReview($data);
			if ($Res == 1) {
				$data['error_message'] = 1;
			} 
			else {
				$data['error_message'] = 'Error !!!';
			}
		}
	}
	echo ($data['error_message']); 
	exit();
}
	
public function getApproval() {   // print_r($_POST); exit;
	$data['pages'] = $this->input->post('pages');
	
	switch($data['pages'])  { 
	case 'hodapprove' :  
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->getHOD_Approval($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
		
	break; 
	
	case 'feasiview' :
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['devp'] = $this->input->post('devp');
		$data['dev_days'] = $this->input->post('dev_days');
		$data['project_date'] = $this->input->post('project_date');		
		$data['enddate'] = $this->input->post('enddate');	
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->getFeasibility($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	case 'itapprove' :
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');
		$data['id'] = $this->input->post('id');
		$data['itprio'] = $this->input->post('itprio');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->geItHeadApproval($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	case 'projdate' :
		$data['startdate'] = $this->input->post('startdate');		
		$data['sts'] = $this->input->post('sts');		
		$data['cmts'] = $this->input->post('cmts');		
		$data['id'] = $this->input->post('id');
		$data['base_url'] = $this->input->post('base_url');
		
		if($this->input->post('sts')) {
			$this->form_validation->set_rules('sts', 'Status', 'required');
				
			if ($this->form_validation->run() == FALSE) {
				$data['error_message'] = validation_errors();
			} 
			else {
				$Res= $this->Request_Model->geTentativeDate($data);
				if ($Res == 1) {
					$data['error_message'] = 1;
				} 
				else {
					$data['error_message'] = 'Error !!!';
				}
			}
		}
		echo ($data['error_message']); 
		exit();
	break;
	
	
	}
	
}		

############## New one by durga 06-09-2021 ###########################################
public function portal_access_request() {
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$this->load->view('NewPortalAccessEntry',$data);
}

public function submit_to_approve(){
	$portal_list = $this->input->post('portal_name');
	$remarks = $this->input->post('remarks');
	$route_to = $this->input->post('route_to');
	$data['portal_list'] =  $portal_list;
	$data['remarks'] =  $remarks;
	$data['route_to'] =  $route_to;
	$data['is_active'] =  1;
	$data['status'] =  'S';
	$data['created_by'] =  $this->session->userdata('empid');
	$data['created_date'] =  date('Y-m-d H:i:s');
	$last_id = $this->Request_Model->createData($data,'portal_access_request');
	
	$data1['query_id'] = $last_id;
	$data1['status'] = 'S';
	$data1['comment'] = 'Submitted';
	$data1['approver_name'] = $this->session->userdata('empname');
	$data1['approved_date'] = date("Y-m-d");
	$this->Request_Model->createData($data1,'comment_master_for_access_request');
	
	$URL = $this->config->item('base_url');
	$emp = $this->user_model->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_username = "'.$this->session->userdata('empuname').'" ');
		
	$message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been Submitted</div><br>';
	$message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
	$message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
	$message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$data['created_date'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$data['portal_list'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$emp.'</td></tr>'; 
	$message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">Submitted</td></tr></table>';
	
	$message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
	$message.='<br>&nbsp;';
	$message.='<br><b>Thanks & Regards,</b>';
	$message.='<br>'.$this->session->userdata('empname').'';
	$message.='<br>Comstar Automotive Technologies Pvt Ltd.,';

	$to = $this->user_model->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_username = "'.$data['route_to'].'" '); 
	
	$subject ="Portal Access Request - Submitted";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	$headers .= "From: ".$this->session->userdata('empemail'). "\r\n";
	$headers .= "Cc: ".$this->session->userdata('empemail'). "\r\n";
	
	// echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
	
	$maildata = @mail($to,$subject,$message,$headers);  
	// if($maildata) { 
		// return 1; 
	// }
	echo 1;
}

public function get_approval_list(){
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$data['p_access_list'] = $this->Request_Model->get_approval_list();
	$data['pageTitle'] = 'Approval';
	$this->load->view('portal_access_list',$data);
}

public function my_access_request_list(){
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$data['p_access_list'] = $this->Request_Model->get_mycreation();
	$data['pageTitle'] = 'My Creation';
	$this->load->view('portal_access_list',$data);
}

public function portal_access_view($id,$urisegment){
	$data['access_id'] = $id;
	$data['urisegment'] = $urisegment;
	$cmaster = $this->Request_Model->getRecords('comment_master_for_access_request','query_id',$id);
	$data['commentsDetails'] = $cmaster->result_array();
	$rdetails = $this->Request_Model->getRecords('portal_access_request','access_id',$id);
	$data['rqDetails'] = $rdetails->row_array();
	$this->load->view('ajax_view_portal_access',$data);
}

public function save_ROApproval(){
	$edit_id = $this->input->post('access_id');
	$data['portal_list'] = $this->input->post('portal_name');
	$data['status'] = $this->input->post('status');
	$this->Request_Model->updateData($data,'portal_access_request','access_id',$edit_id);
	$data1['comment'] = $this->input->post('cmts');
	$data1['query_id'] = $edit_id;
	$data1['status'] =  $this->input->post('status');
	$data1['approver_name'] = $this->session->userdata('empname');
	$data1['approved_date'] = date("Y-m-d");
	$this->Request_Model->createData($data1,'comment_master_for_access_request');
	if($data['status'] == "HA"){
		$text = 'Approved';
	} else {
		$text = 'Rejected';
	}
	
	
	$URL = $this->config->item('base_url');
	$empData = $this->Request_Model->getRecords('portal_access_request','access_id',$edit_id);
	$emp = $empData->row_array();
	$employee = $this->user_model->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_id = "'.$emp['created_by'].'" ');
	$empmail = $this->user_model->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_id = "'.$emp['created_by'].'" ');
		
	$message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been '.$text.' by Ro/HOD</div><br>';
	$message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
	$message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
	$message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$emp['created_date'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$emp['portal_list'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$employee.'</td></tr>'; 
	$message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">RO / HOD '.$text.'</td></tr></table>';
	
	$message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
	$message.='<br>&nbsp;';
	$message.='<br><b>Thanks & Regards,</b>';
	$message.='<br>'.$this->session->userdata('empname').'';
	$message.='<br>Comstar Automotive Technologies Pvt Ltd.,';
	$toArray = array();
	foreach($this->config->item('it_approval') as $user){
		$toArray[] = $this->user_model->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_username = "'.$user.'" '); 
	}
	$to = implode(',',$toArray);
	$subject ="Portal Access Request - ".$text;
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	$headers .= "From: ".$this->session->userdata('empemail'). "\r\n";
	$headers .= "Cc: ".$empmail. "\r\n";
	
	 //echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
	
	$maildata = @mail($to,$subject,$message,$headers);  
	// if($maildata) { 
		// return 1; 
	// }
	echo 1;
}

public function get_IT_approval_list(){
	$data['layout_header'] = $this->load->view("layout/header", "", true);
	$data['layout_footer'] = $this->load->view("layout/footer", "", true);
	$data['layout_sidebar'] = $this->load->view("layout/sidebar", "", true);
	$data['p_access_list'] = $this->Request_Model->get_IT_approval_list();
	$data['pageTitle'] = 'IT Approval';
	$this->load->view('portal_access_list',$data);
}

public function save_ITApproval(){
	$edit_id = $this->input->post('access_id');
	$data['status'] = $this->input->post('status');
	$this->Request_Model->updateData($data,'portal_access_request','access_id',$edit_id);
	$data1['comment'] = $this->input->post('cmts');
	$data1['query_id'] = $edit_id;
	$data1['status'] =  $this->input->post('status');
	$data1['approver_name'] = $this->session->userdata('empname');
	$data1['approved_date'] = date("Y-m-d");
	$this->Request_Model->createData($data1,'comment_master_for_access_request');
	
	if($data['status'] == "C"){
		$text = 'Approved';
	} else {
		$text = 'Rejected';
	}
	
	$URL = $this->config->item('base_url');
	$empData = $this->Request_Model->getRecords('portal_access_request','access_id',$edit_id);
	$emp = $empData->row_array();
	$employee = $this->user_model->getDetails1('cs_emp_name','tbl__cs_employee','cs_emp_id = "'.$emp['created_by'].'" ');
	$empmail = $this->user_model->getDetails1('cs_emp_email','tbl__cs_employee','cs_emp_id = "'.$emp['created_by'].'" ');
		
	$message='<div style="padding:5px;"><b>Dear Sir,</b></div><div style="padding:5px;">Portal Access Request has been '.$text.' by Portal Team</div><br>';
	$message.='<table width="55%" height="45%" cellpadding="2" cellspacing="2" border="1" align="center">';
	$message.='<tr><td colspan="2" align="left" style="background-color:purple; color:white; padding:5px; font-weight:bold"><b>Portal Access Request Details </b></td></tr>';
	$message.='<tr><td width=20% align="right" style="padding:5px;font-weight:bold">Request Date</td><td width=30% style="padding:5px;color:red;">'.$emp['created_date'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Portal Name List</td><td width="30%" style="padding:5px;">'.$emp['portal_list'].'</td></tr>';
	$message.='<tr><td width="20%" align="right" style="padding:5px;font-weight:bold">Requestor Name</td><td width="30%" style="padding:5px;">'.$employee.'</td></tr>'; 
	$message.='<tr><td width="30%" align="right" style="padding:5px;font-weight:bold">Status</td><td width="30%" style="padding:5px;">Portal Team '.$text.'</td></tr></table>';
	
	$message.='<br><a href="'.$URL.'login" style="color:red;text-decoration:underline;">Click here</a> to Login IT Ticketing System.';
	$message.='<br>&nbsp;';
	$message.='<br><b>Thanks & Regards,</b>';
	$message.='<br>'.$this->session->userdata('empname').'';
	$message.='<br>Comstar Automotive Technologies Pvt Ltd.,';
	
	$to = $empmail;
	$subject ="Portal Access Request - ".$text;
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
	$headers .= "From: ".$this->session->userdata('empemail'). "\r\n";
	$headers .= "Cc: ".$this->session->userdata('empemail'). "\r\n";
	
	 //echo $to.'<br/>'.$subject.'<br/>'.$message.'<br/>'.$headers; exit;		
	
	$maildata = @mail($to,$subject,$message,$headers);  
	// if($maildata) { 
		// return 1; 
	// }
	echo 1;
}
}
?>