<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-09 10:32:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:32:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:50:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:50:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:53:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:53:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:56:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:56:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:57:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 10:57:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:02:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:02:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:02:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:02:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:03:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 11:03:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 12:25:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-09 12:25:56 --> 404 Page Not Found: Assets/images
