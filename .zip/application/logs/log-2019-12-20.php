<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-20 14:01:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 14:01:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 14:02:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 14:02:21 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 14:03:16 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 14:03:16 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 15:41:58 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-20 15:41:58 --> 404 Page Not Found: Assets/images
