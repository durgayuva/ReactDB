<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-17 15:50:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-17 15:50:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-17 17:16:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-17 17:16:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-17 17:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-17 17:17:44 --> 404 Page Not Found: Assets/images
