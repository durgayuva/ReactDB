<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 08:06:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 08:06:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 08:09:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 08:09:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:37:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:37:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:38:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:38:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:50:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:50:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:50:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-07 13:50:23 --> 404 Page Not Found: Assets/images
