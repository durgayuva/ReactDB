<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-08 16:40:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:40:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:41:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:44:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:44:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:47:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:47:13 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:52:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-08 16:52:18 --> 404 Page Not Found: Assets/images
