<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-23 09:00:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 09:00:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 09:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 09:04:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 09:12:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 09:12:30 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:30:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:30:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:31:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:31:25 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:52:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 13:52:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:05:13 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:05:14 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:05:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:06:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:06:37 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-23 14:08:36 --> 404 Page Not Found: Assets/images
