<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 16:16:06 --> 404 Page Not Found: Request/Login
ERROR - 2020-12-10 16:18:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-10 16:18:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-10 16:25:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-10 16:25:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-10 17:13:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-10 17:13:03 --> 404 Page Not Found: Assets/images
