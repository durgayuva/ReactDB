<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 15:29:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-28 15:29:53 --> 404 Page Not Found: Assets/images
