<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-22 08:03:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-22 08:03:47 --> 404 Page Not Found: Assets/images
