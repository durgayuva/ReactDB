<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 14:01:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-25 14:01:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-25 14:42:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-08-25 14:42:59 --> 404 Page Not Found: Assets/images
