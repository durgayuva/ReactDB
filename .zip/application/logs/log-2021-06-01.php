<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 15:08:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-01 15:08:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-01 15:44:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-01 15:44:09 --> 404 Page Not Found: Assets/images
