<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-08 07:45:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 07:45:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:08:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:08:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:16:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:16:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:17:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:17:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:27:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-08 08:27:59 --> 404 Page Not Found: Assets/images
