<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-29 08:27:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-07-29 08:27:00 --> 404 Page Not Found: Assets/images
