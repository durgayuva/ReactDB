<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-24 11:13:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-24 11:13:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-24 11:16:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-24 11:16:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-24 11:19:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-24 11:19:27 --> 404 Page Not Found: Assets/images
