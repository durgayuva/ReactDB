<?php
class Comportal {
	var $objInstance;
	//var $config;
	function Comportal() {
		$this->objInstance =& get_instance(); 
	}
	
	function logout() {
		$this->objInstance->session->unset_userdata('empid');  			// Refer controller login (Session)
		$this->objInstance->session->sess_destroy();
		redirect(ADMIN_URL.'login');
	}
	
// User login check
	function userlogincheck() {
		if($this->objInstance->session->userdata("empid") == "") {
			redirect(ADMIN_URL.'login');
		}
	}
	
	// Mail template
	function mailtemplate($content) {
		$baseUrl = $this->objInstance->config->item('base_url');
		$message='<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">';
		$message.='<tr><td width="585" align="center">';
		$message.='<table width="585" cellpadding="0" cellspacing="0" border="0">';
		$message.='<tr bgcolor="#E5C600"><td width="585">';
		$message.='<table width="585" cellpadding="0" cellspacing="0" border="0">';
		$message.='<tr><td width="30%"><img src="'.$baseUrl.'/assets/images/Comstarlogo.gif" width="225" border="0" alt="Rethink your everyday." title="Rethink your everyday." style="display: block;" /></td><td width="70%" align="center" style="font-family:Arial;font-weight:bold;font-size:27px;color:#A82103;">Supplier Portal System</td></tr></table></td></tr>';
		$message.='<tr><td width="585"><img src="'.$baseUrl.'/assets/images/header_btm.jpg" width="585" height="20" border="0" style="display: block;" /></td></tr>';
		$message.='<tr><td width="585">';
		$message.='<table width="585" cellpadding="0" cellspacing="0" border="0"><tr><td width="21" valign="top" bgcolor="#0A4881"><img src="'.$baseUrl.'/assets/images/gradient_lt.jpg" width="21" border="0" style="display: block;" /></td><td width="543" style="background-color: #FFFFFF; vertical-align: top;">';
		$message.='<table width="543" cellpadding="0" cellspacing="0" border="0"><tr><td width="543"><img src="'.$baseUrl.'/assets/images/spacer.gif" width="1" height="10" border="0" style="display: block;" /></td></tr>';
		$message.='<tr><td width="543"><table width="543" cellpadding="0" cellspacing="0" border="0"><tr><td width="20"><img src="'.$baseUrl.'/assets/images/spacer.gif" width="20" height="1" border="0" style="display: block;" /></td><td width="503">';
		$message.='<table width="503" cellpadding="0" cellspacing="0" border="0"><tr><td width="503"><img src="'.$baseUrl.'/assets/images/spacer.gif" width="1" height="10" border="0" style="display: block;" /></td></tr>';
		$message.='<tr style="background:none;"><td width="503">';
		
		/*** Here the dynamic content of the mail part is placed***/
		$message.=$content;
		//$message.='<tr><td>Thank you,</td></tr>';
		//$message.='<tr><td>With Regards,</td></tr>';
		//$message.='<tr><td>Supplier Portal System,</td></tr>';
		//$message.='<tr><td>Comstar Automotive Technologies Pvt Ltd.,</td></tr>';
		$message.='</td></tr></table></td>';
		$message.='<td width="20"><img src="'.$baseUrl.'/assets/images/spacer.gif" width="20" height="1" border="0" style="display: block;" /></td></tr></table></td></tr><tr>';
		$message.='<td width="543"><img src="'.$baseUrl.'/assets/images/spacer.gif" width="1" height="10" border="0" style="display: block;" /></td></tr></table></td>';
		$message.='<td width="21" valign="top" bgcolor="#0A4881"><img src="'.$baseUrl.'/assets/images/gradient_rt.jpg" width="21" border="0" style="display: block;" /></td></tr></table></td></tr>';
		$message.='<tr><td width="585" bgcolor="#004A91">&nbsp;</td></tr>';
		$message.='<tr><td width="585" bgcolor="#E5C600" align="center" height="30" style="font-family:tahoma;font-weight:bold;font-size:11px;color:#fff;">Powered by Comstar auto</td></tr></table></td></tr></table>';
		return $message;
	}
	
	// Money format for India
	public function moneyFormatIndia($num){		
			$explrestunits = "" ;
			$num=preg_replace('/,+/', '', $num);
			$words = explode(".", $num);
			$des="00";
			if(count($words)<=2){
				$num=$words[0];
				if(count($words)>=2){
					$des=$words[1];
				}
				if(strlen($des)<2){
					$des="$des0";
				}
				else{
					$des=substr($des,0,2);
				}
			}
			if(strlen($num)>3){
				$lastthree = substr($num, strlen($num)-3, strlen($num));
				
				// extracts the last three digits
				$restunits = substr($num, 0, strlen($num)-3); 
				
				// explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
				$restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; 
				
				$expunit = str_split($restunits, 2);
				
				for($i=0; $i<sizeof($expunit); $i++){
					// creates each of the 2's group and adds a comma to the end
					if($i==0){
						$explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
					}else{
						$explrestunits .= $expunit[$i].",";
					}
				}
				$thecash = $explrestunits.$lastthree;
			} else {
				$thecash = $num;
			}
			return "$thecash.$des"; // writes the final format where $currency is the currency symbol.		
		}
}