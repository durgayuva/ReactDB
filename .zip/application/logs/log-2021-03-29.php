<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-29 11:23:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-29 11:23:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-29 11:39:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-29 11:39:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-29 15:06:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-29 15:06:28 --> 404 Page Not Found: Assets/images
