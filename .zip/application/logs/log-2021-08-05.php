<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-05 08:51:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-08-05 08:51:56 --> 404 Page Not Found: Assets/images
