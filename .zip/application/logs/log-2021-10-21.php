<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-21 07:39:38 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-21 07:40:24 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-21 07:40:56 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-21 07:41:11 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-21 07:41:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-21 07:41:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-21 07:41:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-21 07:41:55 --> 404 Page Not Found: Assets/images
