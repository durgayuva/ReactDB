<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-28 09:20:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 09:20:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:27:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:27:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:38:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:38:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:39:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:39:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:39:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 14:39:08 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 17:48:09 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-28 17:48:09 --> 404 Page Not Found: Assets/images
