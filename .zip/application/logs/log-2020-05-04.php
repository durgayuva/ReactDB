<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-04 08:29:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-04 08:29:42 --> 404 Page Not Found: Assets/images
