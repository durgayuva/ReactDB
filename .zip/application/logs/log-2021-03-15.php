<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-15 14:31:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-15 14:31:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-15 14:32:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-15 14:32:00 --> 404 Page Not Found: Assets/images
