<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 12:50:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-24 12:50:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-24 12:51:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-24 12:51:50 --> 404 Page Not Found: Assets/images
