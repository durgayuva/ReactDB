<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 09:14:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:14:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:45:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:45:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:45:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:46:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 09:46:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 10:42:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-19 10:42:39 --> 404 Page Not Found: Assets/images
