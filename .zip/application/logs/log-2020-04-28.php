<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-28 14:44:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-28 14:44:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-28 14:58:25 --> 404 Page Not Found: Assets/images
