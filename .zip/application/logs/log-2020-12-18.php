<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-18 11:04:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:04:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:06:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:06:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:11:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:11:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:40:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:40:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:43:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:43:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:43:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:43:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:44:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:44:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 11:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 13:33:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-18 13:33:27 --> 404 Page Not Found: Assets/images
