<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-20 07:40:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 07:40:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 08:13:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 08:13:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:37:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:37:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:58:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:58:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:58:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-20 15:58:55 --> 404 Page Not Found: Assets/images
