<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 17:04:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-11 17:04:30 --> 404 Page Not Found: Assets/images
