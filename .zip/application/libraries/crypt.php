<?php
class Crypt {
	/**
	*Function to encrypt or decrypt the given value
	* @param string
	* @return string
	*/
	function encrypt_decrypt($string) {
		$string_length=strlen($string); 
		$encrypted_string=""; 
		/**
		*For each character of the given string generate the code
		*/
		for ($position = 0;$position<$string_length;$position++){         
			$key = (($string_length+$position)+1);
			$key = (255+$key) % 255;
			$get_char_to_be_encrypted = SUBSTR($string, $position, 1); 
			$ascii_char = ORD($get_char_to_be_encrypted); 
			$xored_char = $ascii_char ^ $key;  //xor operation 
			$encrypted_char = CHR($xored_char); 
			$encrypted_string .= $encrypted_char; 
		} 
		return $encrypted_string; 
	}
	// Encode the string
	function encode($string) {
		$passstring = $string * 12345;
		$encrypted_string = $this->encrypt_decrypt($passstring);
		return urlencode($encrypted_string);
	}
	// Decode the encoded string
	function decode($string) {
		$passstring = urldecode(stripslashes($string));
		$decrypted_string= $this->encrypt_decrypt($passstring);
		return $decrypted_string / 12345;
	}
 }
 ?>