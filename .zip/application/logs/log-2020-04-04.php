<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-04 12:36:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-04 12:36:01 --> 404 Page Not Found: Assets/images
