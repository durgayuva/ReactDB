<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-13 11:24:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-07-13 11:24:35 --> 404 Page Not Found: Assets/images
