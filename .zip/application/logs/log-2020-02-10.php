<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-10 09:28:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:28:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:30:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid = ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2020-02-10 09:30:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid = ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2020-02-10 09:33:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:33:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:33:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:33:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:33:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-02-10 09:33:49 --> 404 Page Not Found: Assets/images
