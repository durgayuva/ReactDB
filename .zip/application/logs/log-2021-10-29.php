<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-29 07:54:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 07:54:46 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 07:58:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 07:58:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:58:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:58:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:59:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:59:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:59:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 09:59:53 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 10:00:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 10:00:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 10:00:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 10:00:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:41:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:41:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:41:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:41:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:42:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-29 13:42:12 --> 404 Page Not Found: Assets/images
