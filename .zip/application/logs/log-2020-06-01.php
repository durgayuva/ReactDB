<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-01 10:26:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-01 10:26:04 --> 404 Page Not Found: Assets/images
