<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-06 12:15:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:15:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:15:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:15:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:16:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:16:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:16:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 12:16:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 16:09:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-06 16:09:39 --> 404 Page Not Found: Assets/images
