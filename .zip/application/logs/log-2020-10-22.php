<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-22 08:55:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 08:55:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 08:56:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 08:56:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 13:48:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 13:48:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 13:48:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 13:48:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 14:21:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-22 14:21:00 --> 404 Page Not Found: Assets/images
