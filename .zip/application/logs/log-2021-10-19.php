<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-19 10:16:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 10:16:21 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 14:10:09 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 14:10:13 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 14:10:23 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 14:10:54 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 14:12:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 14:12:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 14:12:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 14:12:41 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 15:23:16 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 15:23:23 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-10-19 15:31:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 15:31:11 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:00:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:00:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:05:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:05:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:09:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-19 16:09:22 --> 404 Page Not Found: Assets/images
