<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-12 15:31:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:31:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:32:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:32:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:42:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:42:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:43:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-12 15:43:26 --> 404 Page Not Found: Assets/images
