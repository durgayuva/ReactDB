<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-09 09:50:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-09 09:50:52 --> 404 Page Not Found: Assets/images
