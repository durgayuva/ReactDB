<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-06 11:49:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 11:49:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 12:18:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 12:18:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 12:19:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 12:19:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 16:07:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 16:07:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 16:08:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-06 16:08:07 --> 404 Page Not Found: Assets/images
