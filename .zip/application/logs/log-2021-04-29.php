<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-29 08:40:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-29 08:40:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-29 08:43:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-29 08:43:01 --> 404 Page Not Found: Assets/images
