<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-25 08:36:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-25 08:36:24 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-25 08:56:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-25 08:56:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-25 11:04:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-25 11:04:18 --> 404 Page Not Found: Assets/images
