<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-02 09:51:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-02 09:51:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-02 10:00:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-02 10:00:21 --> 404 Page Not Found: Assets/images
