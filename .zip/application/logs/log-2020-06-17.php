<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 12:01:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 12:01:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 12:55:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 12:55:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:27:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:27:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:27:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:27:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:28:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 13:28:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 14:09:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 14:09:15 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 14:09:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 14:09:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:17:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:17:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:18:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:18:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:26:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 15:26:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:48:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:48:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:50:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:50:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:51:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-17 16:51:31 --> 404 Page Not Found: Assets/images
