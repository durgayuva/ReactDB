<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-02 22:53:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-02 22:53:45 --> 404 Page Not Found: Assets/images
