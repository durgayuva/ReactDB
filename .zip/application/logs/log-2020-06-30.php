<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-30 13:17:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-30 13:17:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-30 13:18:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-06-30 13:18:36 --> 404 Page Not Found: Assets/images
