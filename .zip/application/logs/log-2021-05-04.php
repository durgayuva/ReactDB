<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-04 08:32:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-04 08:32:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-04 08:34:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-05-04 08:34:43 --> 404 Page Not Found: Assets/images
