<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-17 12:33:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 12:33:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:20:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:20:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:17 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-17 16:21:57 --> 404 Page Not Found: Assets/images
