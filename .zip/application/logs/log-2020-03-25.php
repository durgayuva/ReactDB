<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-25 11:50:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-25 11:50:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-25 11:51:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-25 11:51:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-25 11:51:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-03-25 11:51:46 --> 404 Page Not Found: Assets/images
