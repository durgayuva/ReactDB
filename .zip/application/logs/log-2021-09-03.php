<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-03 10:26:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:26:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:26:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:26:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:46:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:46:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:57:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-03 10:57:03 --> 404 Page Not Found: Assets/images
