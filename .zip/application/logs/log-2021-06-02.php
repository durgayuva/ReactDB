<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-02 10:44:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-02 10:44:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-02 10:48:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-02 10:48:55 --> 404 Page Not Found: Assets/images
