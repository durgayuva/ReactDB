<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-14 14:58:27 --> 404 Page Not Found: Assets/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-14 14:58:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-14 14:58:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-14 14:58:43 --> 404 Page Not Found: Assets/images
