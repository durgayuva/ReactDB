<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-11 10:40:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-11 10:40:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-11 10:44:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-11 10:44:30 --> 404 Page Not Found: Assets/images
