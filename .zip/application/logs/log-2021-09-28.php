<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-28 12:55:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-28 12:55:54 --> 404 Page Not Found: Assets/images
