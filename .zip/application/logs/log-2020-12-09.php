<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-09 07:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-09 07:58:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-09 13:32:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-09 13:32:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-12-09 13:43:36 --> 404 Page Not Found: Assets/images
