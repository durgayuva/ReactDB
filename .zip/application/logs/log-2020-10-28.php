<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-28 12:36:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 12:36:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:58 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-28 13:17:58 --> 404 Page Not Found: Assets/images
