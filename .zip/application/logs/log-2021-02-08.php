<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-08 09:30:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-08 09:30:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-08 16:30:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-08 16:30:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-08 22:21:03 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-08 22:21:03 --> 404 Page Not Found: Assets/images
