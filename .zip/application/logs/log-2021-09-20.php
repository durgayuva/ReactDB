<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 11:42:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 11:42:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 12:00:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 12:00:43 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 13:55:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 13:55:01 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 13:55:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 13:55:16 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:40 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:44 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:11:47 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:12:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:12:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:28:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:28:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:28:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:28:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:31:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:31:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:45:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 14:45:49 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 15:22:23 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-09-20 15:22:32 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-09-20 15:23:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 15:23:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 15:23:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 15:23:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:25:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:25:23 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:25:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:25:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:26:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:26:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:38:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:38:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:42:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:42:51 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:44:19 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-20 16:44:19 --> 404 Page Not Found: Assets/images
