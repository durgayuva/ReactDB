<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-08 12:24:54 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-09-08 13:27:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 13:27:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 13:31:27 --> Severity: Warning --> ldap_bind(): Unable to bind to server: Invalid credentials D:\htdocs\portal_request\application\controllers\Login.php 52
ERROR - 2021-09-08 13:31:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 13:31:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:22:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:22:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:26:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 14:26:59 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 15:33:56 --> 404 Page Not Found: Assets/images
ERROR - 2021-09-08 15:33:56 --> 404 Page Not Found: Assets/images
