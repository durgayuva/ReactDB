<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-02 08:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-02 08:22:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-02 08:22:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-02 08:22:37 --> 404 Page Not Found: Assets/images
