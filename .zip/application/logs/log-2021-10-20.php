<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-20 10:52:33 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 10:52:34 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:44:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:44:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:44:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:44:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:49:30 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 11:49:31 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 12:23:00 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-20 12:23:00 --> 404 Page Not Found: Assets/images
