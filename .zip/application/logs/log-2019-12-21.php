<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-21 06:43:59 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:44:00 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:44:48 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:45:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:45:24 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:45:29 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:45:29 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:49:29 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:49:29 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:49:56 --> 404 Page Not Found: Assets/images
ERROR - 2019-12-21 06:49:56 --> 404 Page Not Found: Assets/images
