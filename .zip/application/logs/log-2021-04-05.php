<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-05 11:57:38 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-05 11:57:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-05 13:52:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-05 13:52:26 --> 404 Page Not Found: Assets/images
