<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-10 00:51:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 00:51:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 00:57:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 00:57:27 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 07:26:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 07:26:35 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 07:27:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 07:27:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 10:34:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 10:34:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 10:35:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 10:35:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 15:49:25 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 15:49:26 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 15:50:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-06-10 15:50:28 --> 404 Page Not Found: Assets/images
