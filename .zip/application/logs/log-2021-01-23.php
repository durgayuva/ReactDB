<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 11:45:04 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-23 11:45:04 --> 404 Page Not Found: Assets/images
