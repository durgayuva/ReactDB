<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 08:15:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:15:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:16:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead' at line 1 - Invalid query:  SELECT * FROM query_master WHERE 1 AND emp_deptid = ORDER BY FIELD(status,'Submitted', 'HODApproved', 'Feasibility Checked', 'ITHead Approved', 'Inprocess', 'Awaiting for UAT', 'UAT Accepted', 'Rerouted to User', 'Completed', 'Rejected', 'Closed') 
ERROR - 2020-01-22 08:16:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:16:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-01-22 08:17:44 --> 404 Page Not Found: Assets/images
