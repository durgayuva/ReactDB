<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 13:39:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-01-21 13:39:22 --> 404 Page Not Found: Assets/images
