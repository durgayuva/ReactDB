<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-27 11:57:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-27 11:57:06 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-27 11:57:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-27 11:57:15 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-27 12:45:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-10-27 12:45:20 --> 404 Page Not Found: Assets/images
