<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-19 08:38:05 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-19 08:38:05 --> 404 Page Not Found: Assets/images
