<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-07 11:50:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:50:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:51:58 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:52:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:52:28 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:52:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:52:45 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:02 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:53:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:54:05 --> 404 Page Not Found: Assets/images
ERROR - 2021-04-07 11:54:05 --> 404 Page Not Found: Assets/images
